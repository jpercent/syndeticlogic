#!/bin/bash
code_file='rank'$1'.py'
python $code_file $2
