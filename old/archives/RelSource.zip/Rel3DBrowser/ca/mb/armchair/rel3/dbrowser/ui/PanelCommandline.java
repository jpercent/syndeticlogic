package ca.mb.armchair.rel3.dbrowser.ui;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.*;

import java.awt.Font;
import java.awt.event.*;

import ca.mb.armchair.rel3.client.string.*;
import ca.mb.armchair.rel3.client.parser.ResponseProcessor;
import ca.mb.armchair.rel3.client.parser.core.ParseException;
import ca.mb.armchair.rel3.dbrowser.utilities.Preferences;

/**
 * JPanel derivative for displaying a command-line interface.
 *
 * @author  dave
 */
public class PanelCommandline extends javax.swing.JPanel implements EditorOptions {
	private final static long serialVersionUID = 0;
	
	private StringReceiverClient client;
	private String dbURL;

	private javax.swing.Timer scrollTimer;
	private javax.swing.Timer silentTimer;
	private javax.swing.Timer progressTimer;

	private JTextComponent jTextAreaOutput;

	private Vector<String> entryHistory = new Vector<String>();
	private int currentHistoryItem = 0;

	private StringBuffer formattedOut = new StringBuffer();
	private StringBuffer textOut = new StringBuffer();
	private String lastText;

	private boolean inputEnabled = false;

	private static final String[] formattedStyle = {
		"body {font-family: Sans Serif;}",
		"table {border-style: none; border-width: 0px;}",
		"td, tr, th {border-style: solid; border-width: 1px;}"		
	};

	private static String[] getFormattedStyle() {
		ArrayList<String> style = new ArrayList<String>();
		style.add("body {font-size: " + Preferences.getInstance().getInputOutputFont().getSize() + "pt;}");
		for (String styleLine: formattedStyle)
			style.add(styleLine);
		return style.toArray(new String[0]);
	}
	
	private static boolean isLastNonWhitespaceCharacter(String s, char c) {
		int endPosn = s.length() - 1;
		if (endPosn < 0)
			return false;
		while (endPosn >= 0 && Character.isWhitespace(s.charAt(endPosn)))
			endPosn--;
		if (endPosn < 0)
			return false;
		return (s.charAt(endPosn) == c);
	}
	
	/** Refresh display and scroll down. */
	private void scrollDown() {
		Runnable runner = new Runnable() {
			public void run() {
				javax.swing.JScrollBar vscroller = jScrollPaneOutput.getVerticalScrollBar();
				vscroller.setValue(vscroller.getMaximum());
			}			
		};
		if (javax.swing.SwingUtilities.isEventDispatchThread())
			runner.run();
		else
			javax.swing.SwingUtilities.invokeLater(runner);
	}

	/** Set up the scrollTimer. */
	private void initScrollTimer() {
		scrollTimer = new javax.swing.Timer(500, new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				scrollDown();
			}
		});
		scrollTimer.setRepeats(true);
	}

	/** Set up silence timer. */
	private void initSilentTimer() {
		silentTimer = new javax.swing.Timer(500, new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				scrollTimer.stop();
				scrollDown();
			}
		});
		silentTimer.setRepeats(false);
	}
	
	/** Set up the progress timer. */
	private void initProgressTimer() {
		progressTimer = new javax.swing.Timer(250, new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				updateProgress();
			}
		});
		progressTimer.setRepeats(true);
	}

	/** Update output display */
	private void updateOutput() {
		final String mostRecentTextLine = lastText;
		Runnable runner = new Runnable() {
			public void run() {
				if (isEnhancedOutput())
					jTextAreaOutput.setText(formattedOut.toString());
				else
					((JTextArea) jTextAreaOutput).append(mostRecentTextLine);						
			}
		};
		if (javax.swing.SwingUtilities.isEventDispatchThread())
			runner.run();
		else
			javax.swing.SwingUtilities.invokeLater(runner);
		scrollDown();
	}

	/** Initialise timers. */
	private void initTimers() {
		initScrollTimer();
		initSilentTimer();
		initProgressTimer();
	}

	/** Start timer timers. */
	private void startOutputUpdateTimers() {
		scrollTimer.start();
		silentTimer.restart();
	}

	/** Get number of items in History. */
	private int getHistorySize() {
		return entryHistory.size();
	}

	/** Get history item. */
	private String getHistoryItemAt(int index) {
		if (index < 0 || index >= entryHistory.size())
			return null;
		return entryHistory.get(index);
	}

	/** Get previous history item. */
	private String getPreviousHistoryItem() {
		if (currentHistoryItem > 0)
			currentHistoryItem--;
		setButtons();
		return getHistoryItemAt(currentHistoryItem);
	}

	/** Get next history item. */
	private String getNextHistoryItem() {
		currentHistoryItem++;
		if (currentHistoryItem >= entryHistory.size())
			currentHistoryItem = entryHistory.size() - 1;
		setButtons();
		return getHistoryItemAt(currentHistoryItem);
	}

	/** Add a history item. */
	private void addHistoryItem(String s) {
		entryHistory.add(s);
		currentHistoryItem = entryHistory.size() - 1;
		setButtons();
	}

	/** Set up history button status. */
	private void setButtons() {
		jButtonPreviousCommand.setEnabled(currentHistoryItem > 0 && entryHistory.size() > 1);
		jButtonNextCommand.setEnabled(currentHistoryItem < entryHistory.size() - 1
						&& entryHistory.size() > 1);
	}

	/** True if input is enabled. */
	private boolean isInputEnabled() {
		return inputEnabled;
	}

	/** Lock the interface. */
	private void disableInput() {
		jTextAreaInput.setEnabled(false);
		jButtonRun.setEnabled(false);
		inputEnabled = false;
	}

	/** Unlock the interface. */
	private void enableInput() {
		jTextAreaInput.setEnabled(true);
		jButtonRun.setEnabled(true);
		inputEnabled = true;
	}

	/** Initialisation. */
	private void initialise() {
		initComponents();
		// React to changes in the font.
		Preferences.getInstance().addInputOutputFontChangeListener(
				new Preferences.InputOutputFontChangeListener() {
					public void fontChanged(java.awt.Font font) {
						jTextAreaInput.setFont(font);
						jTextAreaOutput.setFont(font);
					}
				});
		initTimers();
		FileNameExtensionFilter filterD = new FileNameExtensionFilter("D source files", "d");
		jFileChooserLoad.addChoosableFileFilter(filterD);
		jFileChooserSave.addChoosableFileFilter(filterD);
		FileNameExtensionFilter filterTXT = new FileNameExtensionFilter("Text files", "txt");
		jFileChooserSaveOutputText.addChoosableFileFilter(filterTXT);
		jFileChooserSaveOutputText.addChoosableFileFilter(filterD);
		jFileChooserSaveOutputText.setDialogTitle("Save Text");
		FileNameExtensionFilter filterHTML = new FileNameExtensionFilter("HTML files", "html", "htm");
		jFileChooserSaveOutputFormatted.addChoosableFileFilter(filterHTML);
		jFileChooserSaveOutputFormatted.setDialogTitle("Save HTML");
		setButtons();
		jCheckBoxEnhanced.setSelected(true);
		setEnhancedOutput(true);		
		disableInput();
		jSplitPaneMain.setDividerLocation(0.75);
	}
	
	/** Creates new form PanelCommandline to connect to Rel server. */
	public PanelCommandline(StringReceiverClient relClient, String dbURL) {
		client = relClient;
		this.dbURL = dbURL;
		initialise();
	}

	public void go() {
		startProcessingDisplay();
		obtainClientResponse(false);
		enableInput();
		endProcessingDisplay();
	}
	
	/** Invoked when client hosts local server. */
	public void serverhosted() {
		systemResponse("Local server hosted.");
	}

	/** Invoked when locally hosted server is lost. */
	public void serverunhosted() {
		badResponse("Local server lost.");
	}

	/** Invoked when panel is closed. */
	public void close() {
		try {
			client.close();
		} catch (IOException ioe) {
			badResponse("Error closing connection: " + ioe.toString());
		}
	}

	private void setEnhancedOutputStyle(JTextPane pane) {
		pane.setContentType("text/html");
		pane.setEditable(false);
		javax.swing.text.html.HTMLEditorKit editorKit = new javax.swing.text.html.HTMLEditorKit();
		javax.swing.text.html.HTMLDocument defaultDocument = (javax.swing.text.html.HTMLDocument) (editorKit.createDefaultDocument());
		pane.setEditorKit(editorKit);
		pane.setDocument(defaultDocument);
		javax.swing.text.html.StyleSheet css = editorKit.getStyleSheet();
		for (String entry: getFormattedStyle())
			css.addRule(entry);
	}

	/** This method is called from within the constructor to
	 * initialize the form.
	 */
	private void initComponents() {
		jFileChooserLoad = new javax.swing.JFileChooser();
		jFileChooserSave = new javax.swing.JFileChooser();
		jFileChooserSaveOutputText = new javax.swing.JFileChooser();
		jFileChooserSaveOutputFormatted = new javax.swing.JFileChooser();
		jFileChooserSaveBackup = new javax.swing.JFileChooser();
		jSplitPaneMain = new javax.swing.JSplitPane();
		jPanelOutput = new javax.swing.JPanel();
		jScrollPaneOutput = new javax.swing.JScrollPane();
		jToolBarOutput = new javax.swing.JToolBar();
		jButtonClearOutput = new javax.swing.JButton();
		jButtonSaveOutputFormatted = new javax.swing.JButton();
		jButtonSaveOutputText = new javax.swing.JButton();
		jButtonCopyToInput = new javax.swing.JButton();
		jCheckBoxEnhanced = new javax.swing.JCheckBox();
		jCheckBoxSuppressOk = new javax.swing.JCheckBox();
		jCheckBoxAutoclear = new javax.swing.JCheckBox();
		jCheckBoxWrapOutput = new javax.swing.JCheckBox();
		jPanelInput = new javax.swing.JPanel();
		jScrollPaneInput = new javax.swing.JScrollPane();
		jTextAreaInput = new javax.swing.JTextArea();
		jToolBarInput = new javax.swing.JToolBar();
		jButtonPreviousCommand = new javax.swing.JButton();
		jButtonNextCommand = new javax.swing.JButton();
		jButtonClearInput = new javax.swing.JButton();
		jButtonLoadCommand = new javax.swing.JButton();
		jButtonSaveCurrent = new javax.swing.JButton();
		jButtonSaveHistory = new javax.swing.JButton();
		jButtonBackup = new javax.swing.JButton();
		jCheckBoxCopyToOutput = new javax.swing.JCheckBox();
		jCheckBoxWrapInput = new javax.swing.JCheckBox();
		jPanelBottom = new javax.swing.JPanel();
		jButtonRun = new javax.swing.JButton();
		jLabelCaretPosition = new javax.swing.JLabel();
		jLabelRunning = new javax.swing.JLabel();
		jTextAreaOutputFormatted = new JTextPane();
		jTextAreaOutputPlain = new JTextArea();

		jFileChooserSave.setDialogType(javax.swing.JFileChooser.SAVE_DIALOG);
		jFileChooserSaveOutputText.setDialogType(javax.swing.JFileChooser.SAVE_DIALOG);
		jFileChooserSaveOutputFormatted.setDialogType(javax.swing.JFileChooser.SAVE_DIALOG);
		jFileChooserSaveBackup.setDialogType(javax.swing.JFileChooser.SAVE_DIALOG);

		setLayout(new java.awt.BorderLayout());

		jSplitPaneMain.setDividerLocation(50);
		jSplitPaneMain.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
		jSplitPaneMain.setResizeWeight(0.75);
		jSplitPaneMain.setLastDividerLocation(50);
		jSplitPaneMain.setOneTouchExpandable(true);
		jPanelOutput.setLayout(new java.awt.BorderLayout());

		jScrollPaneOutput.setAutoscrolls(true);
		jPanelOutput.add(jScrollPaneOutput, java.awt.BorderLayout.CENTER);

		jToolBarOutput.setRollover(true);
		jToolBarOutput.setFloatable(false);
		jToolBarOutput.setName("Rel Output Toolbar");
		jButtonClearOutput.setFont(new java.awt.Font("Dialog", 0, 10));
		jButtonClearOutput.setText("Clear");
		jButtonClearOutput
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						clearOutput();
					}
				});

		jToolBarOutput.add(jButtonClearOutput);

		jButtonSaveOutputFormatted.setFont(new java.awt.Font("Dialog", 0, 10));
		jButtonSaveOutputFormatted.setText("Save as HTML");
		jButtonSaveOutputFormatted
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						saveOutputFormatted();
					}
				});

		jToolBarOutput.add(jButtonSaveOutputFormatted);

		jButtonSaveOutputText.setFont(new java.awt.Font("Dialog", 0, 10));
		jButtonSaveOutputText.setText("Save as text");
		jButtonSaveOutputText
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						saveOutputText();
					}
				});

		jToolBarOutput.add(jButtonSaveOutputText);

		jButtonCopyToInput.setFont(new java.awt.Font("Dialog", 0, 10));
		jButtonCopyToInput.setText("Copy to Input");
		jButtonCopyToInput
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						copyOutputToInput();
					}
				});

		jToolBarOutput.add(jButtonCopyToInput);

		jCheckBoxEnhanced.setFont(new java.awt.Font("Dialog", 0, 10));
		jCheckBoxEnhanced.setText("Enhanced");
		jCheckBoxEnhanced
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						setEnhancedOutput(jCheckBoxEnhanced.isSelected());
					}
				});

		jToolBarOutput.add(jCheckBoxEnhanced);

		jCheckBoxSuppressOk.setFont(new java.awt.Font("Dialog", 0, 10));
		jCheckBoxSuppressOk.setText("Suppress 'Ok.'");

		jToolBarOutput.add(jCheckBoxSuppressOk);
		
		jCheckBoxAutoclear.setFont(new java.awt.Font("Dialog", 0, 10));
		jCheckBoxAutoclear.setSelected(true);
		jCheckBoxAutoclear.setText("Autoclear");
		jCheckBoxAutoclear.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				if (!jCheckBoxAutoclear.isSelected())
					javax.swing.JOptionPane.showMessageDialog(null, "Allowing the output to grow without clearing it regularly may cause you to run out of memory!", "WARNING", javax.swing.JOptionPane.WARNING_MESSAGE);				
			}
		});
		jToolBarOutput.add(jCheckBoxAutoclear);

		jCheckBoxWrapOutput.setFont(new java.awt.Font("Dialog", 0, 10));
		jCheckBoxWrapOutput.setSelected(true);
		jCheckBoxWrapOutput.setText("Wrap");
		jCheckBoxWrapOutput
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						if (jTextAreaOutput instanceof JTextArea)
							((JTextArea) jTextAreaOutput).setLineWrap(jCheckBoxWrapOutput
									.isSelected());
					}
				});

		jToolBarOutput.add(jCheckBoxWrapOutput);

		jPanelOutput.add(jToolBarOutput, java.awt.BorderLayout.NORTH);

		jSplitPaneMain.setTopComponent(jPanelOutput);

		jPanelInput.setLayout(new java.awt.BorderLayout());

		jTextAreaInput.setLineWrap(true);
		jTextAreaInput.setFont(Preferences.getInstance().getInputOutputFont());
		jTextAreaInput
				.setToolTipText("Enter Tutorial D code here.  Press F5 to execute.");
		jTextAreaInput.setEnabled(false);
		jTextAreaInput.addCaretListener(new javax.swing.event.CaretListener() {
			public void caretUpdate(javax.swing.event.CaretEvent evt) {
				int offset = evt.getDot();
				try {
					int line = jTextAreaInput.getLineOfOffset(offset);
					int column = offset - jTextAreaInput.getLineStartOffset(line);
					jLabelCaretPosition.setText("" + (line + 1) + ":" + (column + 1));
				} catch (BadLocationException ble) {
					jLabelCaretPosition.setText("?:?");
				}
				if (isLastNonWhitespaceCharacter(jTextAreaInput.getText(), ';')) {
					jButtonRun.setText("Execute (F5)");
				} else {
					jButtonRun.setText("Evaluate (F5)");
				}
			}
		});
		jTextAreaInput.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyReleased(java.awt.event.KeyEvent evt) {
				PanelCommandline.this.keyReleased(evt);
			}
		});
		Preferences.getInstance().addInputOutputFontChangeListener(new Preferences.InputOutputFontChangeListener() {
			public void fontChanged(Font font) {
				jTextAreaInput.setFont(Preferences.getInstance().getInputOutputFont());
			}
		});

		jScrollPaneInput.setViewportView(jTextAreaInput);

		jPanelInput.add(jScrollPaneInput, java.awt.BorderLayout.CENTER);

		jToolBarInput.setRollover(true);
		jToolBarInput.setFloatable(false);
		jToolBarInput.setName("Rel Input Toolbar");
		jButtonPreviousCommand.setFont(new java.awt.Font("Dialog", 0, 10));
		jButtonPreviousCommand.setText("<");
		jButtonPreviousCommand
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						previousCommand();
					}
				});

		jToolBarInput.add(jButtonPreviousCommand);

		jButtonNextCommand.setFont(new java.awt.Font("Dialog", 0, 10));
		jButtonNextCommand.setText(">");
		jButtonNextCommand
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						nextCommand();
					}
				});

		jToolBarInput.add(jButtonNextCommand);

		jButtonClearInput.setFont(new java.awt.Font("Dialog", 0, 10));
		jButtonClearInput.setText("Clear");
		jButtonClearInput
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						clearInput();
					}
				});

		jToolBarInput.add(jButtonClearInput);

		jButtonLoadCommand.setFont(new java.awt.Font("Dialog", 0, 10));
		jButtonLoadCommand.setText("Load");
		jButtonLoadCommand
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						loadCommand();
					}
				});

		jToolBarInput.add(jButtonLoadCommand);

		jButtonSaveCurrent.setFont(new java.awt.Font("Dialog", 0, 10));
		jButtonSaveCurrent.setText("Save");
		jButtonSaveCurrent
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						saveCommandCurrent();
					}
				});

		jToolBarInput.add(jButtonSaveCurrent);

		jButtonSaveHistory.setFont(new java.awt.Font("Dialog", 0, 10));
		jButtonSaveHistory.setText("Save history");
		jButtonSaveHistory
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						saveCommandHistory();
					}
				});

		jToolBarInput.add(jButtonSaveHistory);

		jCheckBoxCopyToOutput.setFont(new java.awt.Font("Dialog", 0, 10));
		jCheckBoxCopyToOutput.setSelected(true);
		jCheckBoxCopyToOutput.setText("Copy to output");
		
		jToolBarInput.add(jCheckBoxCopyToOutput);

		jCheckBoxWrapInput.setFont(new java.awt.Font("Dialog", 0, 10));
		jCheckBoxWrapInput.setSelected(true);
		jCheckBoxWrapInput.setText("Wrap");
		jCheckBoxWrapInput
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						jTextAreaInput.setLineWrap(jCheckBoxWrapInput.isSelected());
					}
				});

		jToolBarInput.add(jCheckBoxWrapInput);

		jButtonBackup.setFont(new java.awt.Font("Dialog", 0, 10));
		jButtonBackup.setText("Backup");
		jButtonBackup.setToolTipText("Make a backup of the database.");
		jButtonBackup.setEnabled(true);
		jButtonBackup.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				doBackup();
			}
		});

		jToolBarInput.add(new JSeparator());
		jToolBarInput.add(jButtonBackup);
		
		jPanelInput.add(jToolBarInput, java.awt.BorderLayout.NORTH);

		jPanelBottom.setLayout(new java.awt.BorderLayout());

		jButtonRun.setFont(new java.awt.Font("Dialog", 0, 10));
		jButtonRun.setText("Run (F5)");
		jButtonRun.setToolTipText("Execute code.");
		jButtonRun.setEnabled(false);
		jButtonRun.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				doRun();
			}
		});

		jPanelBottom.add(jButtonRun, java.awt.BorderLayout.CENTER);

		jLabelCaretPosition.setFont(new java.awt.Font("Dialog", 0, 10));
		jLabelCaretPosition.setBorder(new javax.swing.border.EtchedBorder());
		jLabelCaretPosition.setPreferredSize(new java.awt.Dimension(100, 0));
		jPanelBottom.add(jLabelCaretPosition, java.awt.BorderLayout.WEST);

		jLabelRunning.setFont(new java.awt.Font("Dialog", 0, 10));
		jLabelRunning.setBorder(new javax.swing.border.EtchedBorder());
		jLabelRunning.setPreferredSize(new java.awt.Dimension(100, 0));
		jPanelBottom.add(jLabelRunning, java.awt.BorderLayout.EAST);
		
		jPanelInput.add(jPanelBottom, java.awt.BorderLayout.SOUTH);

		jSplitPaneMain.setBottomComponent(jPanelInput);

		add(jSplitPaneMain, java.awt.BorderLayout.CENTER);

		jTextAreaOutputPlain.setToolTipText("Rel server responses are displayed here.");
		jTextAreaOutputPlain.setFont(Preferences.getInstance().getInputOutputFont());
		((JTextArea) jTextAreaOutputPlain).setText(textOut.toString());
		jTextAreaOutputFormatted.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyReleased(java.awt.event.KeyEvent evt) {
				PanelCommandline.this.keyReleased(evt);
			}
		});
		Preferences.getInstance().addInputOutputFontChangeListener(new Preferences.InputOutputFontChangeListener() {
			public void fontChanged(Font font) {
				jTextAreaOutputPlain.setFont(Preferences.getInstance().getInputOutputFont());
			}
		});
		
		jTextAreaOutputFormatted = new JTextPane();
		jTextAreaOutputFormatted.setToolTipText("Rel server responses are displayed here.");				
		setEnhancedOutputStyle((JTextPane)jTextAreaOutputFormatted);
		jTextAreaOutputFormatted.setDoubleBuffered(true);
		jTextAreaOutputFormatted.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyReleased(java.awt.event.KeyEvent evt) {
				PanelCommandline.this.keyReleased(evt);
			}
		});
		Preferences.getInstance().addInputOutputFontChangeListener(new Preferences.InputOutputFontChangeListener() {
			public void fontChanged(Font font) {
				setEnhancedOutputStyle((JTextPane)jTextAreaOutputFormatted);
				jTextAreaOutputFormatted.setText(formattedOut.toString());
			}
		});
	}

	private void keyReleased(java.awt.event.KeyEvent evt) {
		if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_F5)
			doRun();
	}

	private boolean isEnhancedOutput() {
		return (jTextAreaOutput instanceof JTextPane);
	}

	public void save() {
		jTextAreaOutput.setFont(Preferences.getInstance().getInputOutputFont());
		jTextAreaInput.setFont(Preferences.getInstance().getInputOutputFont());
	}
	
	private void setEnhancedOutput(boolean flag) {
		if (jTextAreaOutput != null && flag == isEnhancedOutput())
			return;
		if (flag) {
			jCheckBoxWrapOutput.setEnabled(false);
			jTextAreaOutputFormatted.setText(formattedOut.toString());
			jScrollPaneOutput.setViewportView(jTextAreaOutputFormatted);
			jTextAreaOutput = jTextAreaOutputFormatted;
		} else {			
			((JTextArea) jTextAreaOutputPlain).setLineWrap(jCheckBoxWrapOutput.isSelected());
			jCheckBoxWrapOutput.setEnabled(true);
			jTextAreaOutputPlain.setText(textOut.toString());
			jScrollPaneOutput.setViewportView(jTextAreaOutputPlain);
			jTextAreaOutput = jTextAreaOutputPlain;
		}
		startOutputUpdateTimers();
	}

	private void saveOutput(final String text, final JFileChooser chooser) {
		if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
			if (chooser.getSelectedFile().isFile())
				if (JOptionPane.showConfirmDialog(this, "File "
						+ chooser.getSelectedFile()
						+ " already exists.  Overwrite it?") != JOptionPane.YES_OPTION)
					return;
			startProcessingDisplay();
			setProcessingDisplay("Saving");
			(new javax.swing.SwingWorker<Object, Object>() {
				protected Object doInBackground() throws Exception {
					try {
						BufferedWriter f = new BufferedWriter(new FileWriter(chooser.getSelectedFile()));
						f.write(text);
						f.close();
						systemResponse("Saved " + chooser.getSelectedFile());
					} catch (IOException ioe) {
						badResponse(ioe.toString());
					}
					endProcessingDisplay();
					return null;
				}
			}).execute();
		}		
	}
	
	private void saveOutputText() {
		saveOutput(textOut.toString(), jFileChooserSaveOutputText);
	}

	private void saveOutputFormatted() {
		BufferedReader htmlStreamed = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(jTextAreaOutput.getText().getBytes())));
		StringBuffer output = new StringBuffer();
		String line;
		try {
			while ((line = htmlStreamed.readLine()) != null) {
				if (line.trim().equalsIgnoreCase("<head>")) {
					output.append("<head>\n");
					output.append("<style type=\"text/css\">\n");
					output.append("<!--\n");
					for (String entry: getFormattedStyle()) {
						output.append(entry);
						output.append('\n');
					}
					output.append("-->\n");
					output.append("</style>\n");
					output.append("</head>\n");
				} else if (!line.trim().equalsIgnoreCase("</head>")) {
					output.append(line);
					output.append('\n');
				}
			}
			saveOutput(output.toString(), jFileChooserSaveOutputFormatted);
		} catch (IOException e) {
			System.err.println("This cannot possibly have happened.  The universe has collapsed.");
		}
	}

	private void copyOutputToInput() {
		jTextAreaInput.setText(textOut.toString());
		jTextAreaInput.requestFocus();
	}

	private void clearOutput() {
		formattedOut = new StringBuffer();
		textOut = new StringBuffer();
		lastText = "";
		if (!isEnhancedOutput())
			jTextAreaOutput.setText("");
		updateOutput();
	}

	private void clearInput() {
		jTextAreaInput.setText("");
		jTextAreaInput.requestFocus();
	}

	private void saveCommandHistory() {
		if (jFileChooserSave.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
			if (jFileChooserSave.getSelectedFile().isFile())
				if (JOptionPane.showConfirmDialog(this, "File "
						+ jFileChooserSave.getSelectedFile()
						+ " already exists.  Overwrite it?") != JOptionPane.YES_OPTION)
					return;
			startProcessingDisplay();
			setProcessingDisplay("Saving");
			(new javax.swing.SwingWorker<Object, Object>() {
				protected Object doInBackground() throws Exception {
					try {
						BufferedWriter f = new BufferedWriter(new FileWriter(jFileChooserSave.getSelectedFile()));
						for (int i = 0; i < getHistorySize(); i++) {
							f.write("// History item #" + (i + 1) + "\n");
							f.write(getHistoryItemAt(i));
							f.write("\n\n");
						}
						f.write("// Current entry" + "\n");
						f.write(jTextAreaInput.getText());
						f.close();
						systemResponse("Saved " + jFileChooserSave.getSelectedFile());
						jTextAreaInput.requestFocusInWindow();
					} catch (IOException ioe) {
						badResponse(ioe.toString());
					}
					endProcessingDisplay();
					return null;
				}
			}).execute();
		}
	}

	private void saveCommandCurrent() {
		if (jFileChooserSave.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
			if (jFileChooserSave.getSelectedFile().isFile())
				if (JOptionPane.showConfirmDialog(this, "File "
						+ jFileChooserSave.getSelectedFile()
						+ " already exists.  Overwrite it?") != JOptionPane.YES_OPTION)
					return;
			startProcessingDisplay();
			setProcessingDisplay("Saving");
			(new javax.swing.SwingWorker<Object, Object>() {
				protected Object doInBackground() throws Exception {
					try {
						BufferedWriter f = new BufferedWriter(new FileWriter(
								jFileChooserSave.getSelectedFile()));
						f.write(jTextAreaInput.getText());
						f.close();
						systemResponse("Saved " + jFileChooserSave.getSelectedFile());
						jTextAreaInput.requestFocusInWindow();
					} catch (IOException ioe) {
						badResponse(ioe.toString());
					}
					endProcessingDisplay();
					return null;
				}
			}).execute();
		}
	}

	private void loadCommand() {
		if (jFileChooserLoad.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
			startProcessingDisplay();
			setProcessingDisplay("Loading");
			(new javax.swing.SwingWorker<Object, Object>() {
				protected Object doInBackground() throws Exception {
					try {
						BufferedReader f = new BufferedReader(new FileReader(
								jFileChooserLoad.getSelectedFile()));
						StringBuffer fileImage = new StringBuffer();
						String line;
						while ((line = f.readLine()) != null) {
							fileImage.append(line);
							fileImage.append('\n');
						}
						jTextAreaInput.setText(fileImage.toString());
						jFileChooserSave.setSelectedFile(jFileChooserLoad
								.getSelectedFile());
						systemResponse("Loaded " + jFileChooserLoad.getSelectedFile());
						jTextAreaInput.requestFocusInWindow();
					} catch (IOException ioe) {
						badResponse(ioe.toString());
					}
					endProcessingDisplay();
					return null;
				}
			}).execute();
		}
	}

	private void nextCommand() {
		jTextAreaInput.setText(getNextHistoryItem());
		jTextAreaInput.selectAll();
		jTextAreaInput.requestFocusInWindow();
	}

	private void previousCommand() {
		jTextAreaInput.setText(getPreviousHistoryItem());
		jTextAreaInput.selectAll();
		jTextAreaInput.requestFocusInWindow();
	}

	/** Set display to quick mode and start output timers. */
	private void outputUpdated() {
		updateOutput();
		startOutputUpdateTimers();
	}
	
	/** Clean HTML */
	private String textToHTML(String s) {
		return s.replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>").replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	
	private void outputHTML(String s) {
		formattedOut.append(s);
	}
	
	/** Record formatted responses. */
	private void responseFormatted(String s, boolean parseResponse) {
		if (parseResponse) {
			try {
				setProcessingDisplay("Formatting");
				(new ResponseProcessor(s) {
					boolean headingDisplayed = false;

					public void beginAttributeSpec() {
						outputHTML("<th valign=\"top\">");
					}
					
					public void attributeName(String name) {
						outputHTML(name + "<br>");
					}
					
					public void typeReference(String name) {
						outputHTML("<font size=\"1\"><i>" + name + "</i></font>");
					}
					
					public void endAttributeSpec() {
						outputHTML("</th>");
					}
					
					public void beginTupleDefinition() {
						outputHTML("<font size=\"1\"><i>TUPLE</i></font><table cellpadding=\"1\" cellspacing=\"0\" width=\"100%\">");
					}
					
					public void endTupleDefinition() {
						outputHTML("</table>");
					}
					
					public void beginContainerDefinition() {
						outputHTML("<font size=\"1\"><i>RELATION</i></font><table cellpadding=\"1\" cellspacing=\"0\" width=\"100%\">");
					}
					
					public void endContainerDefinition() {
						outputHTML("</table>");
					}
					
					public void beginHeading() {
						outputHTML("<tr>");
						headingDisplayed = true;
					}
					
					public void endHeading() {
						outputHTML("</tr>");
					}
					
					public void beginContainer(int depth) {
						if (depth == 0)
							outputHTML("<table cellpadding=\"1\" cellspacing=\"0\">");
						else
							outputHTML("<td valign=\"top\"><table cellpadding=\"1\" cellspacing=\"0\" width=\"100%\">");
					}
					
					public void endContainer(int depth) {
						outputHTML("</table>");
						if (depth > 0)
							outputHTML("</td>");
					}
					
					public void beginTuple(int depth) {
						if (headingDisplayed && depth == 1)
							outputHTML("<td valign=\"top\">");
						if (depth != 2) {
							if (depth == 1)
								outputHTML("<table cellpadding=\"1\" cellspacing=\"0\" width=\"100%\">");
							else
								outputHTML("<table cellpadding=\"1\" cellspacing=\"0\">");
						}
						outputHTML("<tr>");
					}
					
					public void endTuple(int depth) {
						outputHTML("</tr>");
						if (depth != 2)
							outputHTML("</table>");						
						if (headingDisplayed && depth == 1)
							outputHTML("</td>");
					}
					
					public void attributeNameInTuple(int depth, String name) {
						if (!headingDisplayed)
							outputHTML("<td valign=\"top\"><i>" + name + "</i> ");
					}
					
					public void beginScalar(int depth) {
						if (depth == 0)
							outputHTML("<br>");
						else if (headingDisplayed)
							outputHTML("<td valign=\"top\">");
					}
					
					public void endScalar(int depth) {
						if (depth != 0 && headingDisplayed)
							outputHTML("</td>");
					}
					
					public void beginPossrep(String name) {
						outputHTML(name + "(");
					}
					
					public void endPossrep() {
						outputHTML(")");
					}
					
					public void separatePossrepComponent() {
						outputHTML(", ");
					}
					
					public void primitive(String value) {
						outputHTML(textToHTML(value));						
					}
					
				}).parse();
			} catch (ParseException pe) {
				outputHTML("<br>" + textToHTML(s));
			}
		} else {
			outputHTML("<br>" + textToHTML(s).replace(" ", "&nbsp;"));
		}
	}

	/** Record text responses. */
	private void responseText(String s) {
		lastText = s + '\n';
		textOut.append(s);
		textOut.append('\n');
	}

	/** Handle a received line of 'good' content. */
	private void goodResponse(String s) {
		formattedOut.append("<font color=\"green\">");
		responseFormatted(s, false);
		formattedOut.append("</font>");
		responseText(s);
		outputUpdated();
	}

	/** Handle user entry. */
	private void userResponse(String s) {
		formattedOut.append("<br><font color=\"gray\"><b>");
		responseFormatted(s, false);
		formattedOut.append("</b></font>");
		responseText(s);
		outputUpdated();
	}

	/** Handle a received line of system notice. */
	private void systemResponse(String s) {
		formattedOut.append("<font color=\"blue\">");
		responseFormatted(s, false);
		formattedOut.append("</font>");
		responseText(s);
		outputUpdated();
	}

	/** Handle a received line of 'bad' content. */
	private void badResponse(String s) {
		formattedOut.append("<pre><font color=\"red\"><b>");
		responseFormatted(s, false);
		formattedOut.append("</b></pre></font>");
		responseText(s);
		outputUpdated();
	}
		
	/** Handle a notice. */
	private void noticeResponse(String s) {
		formattedOut.append("<font color=\"black\"><b>");
		responseFormatted(s, false);
		formattedOut.append("</b></font>");
		responseText(s);
		outputUpdated();		
	}
	
	/** Handle received data. */
	private void response(String s, boolean interpretResponse) {
		responseFormatted(s, interpretResponse);
		responseText(s);
		outputUpdated();
	}

	private void obtainClientResponse(boolean responseFormatted) {
		try {
			StringBuffer reply = new StringBuffer();
			String r;
			while ((r = client.receive()) != null) {
				if (r.equals("\n")) {
					continue;
				} else if (r.equals("Ok.")) {
					response(reply.toString(), false);
					if (!jCheckBoxSuppressOk.isSelected())
						goodResponse(r);		
					reply = new StringBuffer();
				} else if (r.startsWith("ERROR:")) {
					response(reply.toString(), false);
					badResponse(r);
					reply = new StringBuffer();
				} else if (r.startsWith("NOTICE")) {
					response(reply.toString(), false);
					noticeResponse(r);
					reply = new StringBuffer();
				} else {
					reply.append(r);
					reply.append("\n");
				}
			}
			if (reply.length() > 0) {
				response(reply.toString(), responseFormatted);
			}
		} catch (IOException ioe) {
			badResponse(ioe.toString());
			disableInput();
		}
	}
	
	private void updateProgress() {
		Runnable runner = new Runnable() {
			public void run() {
				if (jLabelRunning.getText().endsWith("..."))
					jLabelRunning.setText(jLabelRunning.getText().replace("...", "."));
				else if (jLabelRunning.getText().endsWith("."))
					jLabelRunning.setText(jLabelRunning.getText().concat("."));
			}			
		};
		if (javax.swing.SwingUtilities.isEventDispatchThread())
			runner.run();
		else
			javax.swing.SwingUtilities.invokeLater(runner);
	}
	
	private int processingDisplayCount = 0;
	
	private void startProcessingDisplay() {
		if (processingDisplayCount++ > 0)
			return;
		if (!progressTimer.isRunning())
			progressTimer.start();
		jLabelRunning.setText("Processing...");
	}
	
	private void setProcessingDisplay(final String text) {
		jLabelRunning.setText(text + "...");
	}
	
	private void endProcessingDisplay() {
		if (--processingDisplayCount > 0)
			return;
		else if (processingDisplayCount < 0)
			processingDisplayCount = 0;
		if (progressTimer.isRunning())
			progressTimer.stop();
		jLabelRunning.setText("");
	}
	
	private void doRun() {
		if (!isInputEnabled())
			return;
		(new javax.swing.SwingWorker<Object, Object>() {
			public Object doInBackground() {
				startProcessingDisplay();
				disableInput();
				if (jCheckBoxAutoclear.isSelected())
					clearOutput();
				addHistoryItem(jTextAreaInput.getText());
				if (jCheckBoxCopyToOutput.isSelected())
					userResponse(jTextAreaInput.getText());
				String runMe = jTextAreaInput.getText().trim();
				try {
					if (isLastNonWhitespaceCharacter(runMe, ';')) {
						client.sendExecute(runMe);
						setProcessingDisplay("Receiving");
						obtainClientResponse(false);
					} else {
						client.sendEvaluate(runMe);
						setProcessingDisplay("Receiving");
						obtainClientResponse(true);
					}
				} catch (Throwable ioe) {
					badResponse(ioe.getMessage());
				}
				enableInput();
				jTextAreaInput.selectAll();
				jTextAreaInput.requestFocusInWindow();
				Runnable runner = new Runnable() {
					public void run() {
						endProcessingDisplay();
					}
				};
				if (javax.swing.SwingUtilities.isEventDispatchThread())
					runner.run();
				else
					javax.swing.SwingUtilities.invokeLater(runner);		
				return null;
			}
		}).execute();
	}
	
	private static class BackupResponse {
		private String message;
		private String title;
		private int messageType;
		private boolean succeeded;
		public BackupResponse(String message, String title, int messageType, boolean succeeded) {
			this.message = message;
			this.title = title;
			this.messageType = messageType;
			this.succeeded = succeeded;
		}
		public void showMessageDialog() {
			javax.swing.JOptionPane.showMessageDialog(null, message, title, messageType);
		}
		public boolean isSuccessful() {
			return succeeded;
		}
		public String getMessage() {
			return message;
		}
	}
	
	public BackupResponse backupToFile(File outputFile) {
		String backupScript;
		try {
			File backupScriptFile = new File("Scripts/DatabaseToScript.d");
			BufferedReader f = new BufferedReader(new FileReader(backupScriptFile));
			StringBuffer fileImage = new StringBuffer();
			String line;
			while ((line = f.readLine()) != null) {
				fileImage.append(line);
				fileImage.append('\n');
			}
			backupScript = fileImage.toString();
		} catch (IOException ioe) {
			return new BackupResponse(ioe.toString(), "Unable to load backup script", javax.swing.JOptionPane.ERROR_MESSAGE, false);
		}
		BufferedWriter outf;
		try {
			outf = new BufferedWriter(new FileWriter(outputFile));
		} catch (IOException ioe) {
			return new BackupResponse(ioe.toString(), "Unable to open output file", javax.swing.JOptionPane.ERROR_MESSAGE, false);			
		}
		boolean receivedOk = false;
		long linesWritten = 0;
		try {
			StringReceiverClient client = ClientFromURL.openConnection(dbURL);
			String r;
			while ((r = client.receive()) != null)
				continue;
			client.sendExecute(backupScript);
			try {
				while ((r = client.receive()) != null) {
					if (r.equals("\n")) {
						continue;
					} else if (r.equals("Ok.")) {
						receivedOk = true;
						break;
					} else if (r.startsWith("ERROR:")) {
						outf.close();
						client.close();
						return new BackupResponse(r, "Error executing backup script", javax.swing.JOptionPane.ERROR_MESSAGE, false);
					} else if (r.startsWith("NOTICE")) {
					} else {
						linesWritten++;
						outf.write(r);
						outf.newLine();
					}
				}
			} catch (IOException ioe) {
				outf.close();
				client.close();
				return new BackupResponse(ioe.toString(), "Error executing backup script", javax.swing.JOptionPane.ERROR_MESSAGE, false);
			}			
			client.close();
		} catch (Throwable t) {
			try {
				outf.close();
				if (client != null)
					client.close();
			} catch (IOException e) {
				return new BackupResponse(e.toString(), "Error closing output file", javax.swing.JOptionPane.ERROR_MESSAGE, false);
			}
			return new BackupResponse(t.toString(), "Unable to open database for backup", javax.swing.JOptionPane.ERROR_MESSAGE, false);
		}
		try {
			outf.close();
		} catch (IOException ioe) {
			return new BackupResponse(ioe.toString(), "Unable to close output file", javax.swing.JOptionPane.ERROR_MESSAGE, false);			
		}
		if (receivedOk) {
			if (linesWritten == 0)
				return new BackupResponse("No data was written to the backup.", "Backup failed", javax.swing.JOptionPane.ERROR_MESSAGE, false);
			else {
				BufferedReader inf = null;
				long linesRead = 0;
				try {
					inf = new BufferedReader(new FileReader(outputFile));
					while (inf.readLine() != null)
						linesRead++;
				} catch (IOException ioe) {
					try {
						if (inf != null)
							inf.close();
					} catch (IOException ioe2) {
						return new BackupResponse(ioe2.toString(), "Unable to close backup file after reading it", javax.swing.JOptionPane.ERROR_MESSAGE, false);			
					}
					return new BackupResponse(ioe.toString(), "Unable to read backup file", javax.swing.JOptionPane.ERROR_MESSAGE, false);
				}
				try {
					if (inf != null)
						inf.close();
				} catch (IOException ioe2) {
					return new BackupResponse(ioe2.toString(), "Unable to close backup file after reading it", javax.swing.JOptionPane.ERROR_MESSAGE, false);
				}
				if (linesWritten == linesRead)				
					return new BackupResponse("Backup Successful!  " + linesWritten + " lines were written to\n" + outputFile + "\n\nHowever, you should examine the file to make sure it is complete.", "Backup Complete", javax.swing.JOptionPane.INFORMATION_MESSAGE, true);
				else
					return new BackupResponse("Backup Failed:  " + linesWritten + " lines were written to\n" + outputFile + "\nbut only " + linesRead + " could be read back.", "Backup Failed", javax.swing.JOptionPane.ERROR_MESSAGE, false);
			}
		} else
			return new BackupResponse("The backup may be incomplete.  Please examine the backup!", "Backup Incomplete", javax.swing.JOptionPane.ERROR_MESSAGE, false);
	}
	
	private String getSuggestedBackupFileName() {
		String fname;
		if (dbURL.startsWith("local:"))
			fname = dbURL.substring(6).replace('.', '_').replace('/', '_').replace('\\', '_').replace(':', '_').replace(' ', '_');
		else
			fname = dbURL.replace('.', '_').replace('/', '_').replace('\\', '_').replace(':', '_').replace(' ', '_');
		fname = fname.replace("__", "_");
	    Calendar cal = Calendar.getInstance();
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MMMMM_dd_hh_mm_aaa");
		String timestamp = sdf.format(cal.getTime());
		return "relbackup_" + fname + "_" + timestamp + ".d";
	}
	
	public void doBackup() {
		jFileChooserSaveBackup.setSelectedFile(new File(getSuggestedBackupFileName()));
		if (jFileChooserSaveBackup.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
			if (jFileChooserSaveBackup.getSelectedFile().isFile())
				if (JOptionPane.showConfirmDialog(this, "File "
						+ jFileChooserSaveBackup.getSelectedFile()
						+ " already exists.  Overwrite it?") != JOptionPane.YES_OPTION)
					return;
			startProcessingDisplay();
			setProcessingDisplay("Saving");
			(new javax.swing.SwingWorker<Object, Object>() {
				protected Object doInBackground() throws Exception {
					BackupResponse response = backupToFile(jFileChooserSaveBackup.getSelectedFile());
					endProcessingDisplay();
					if (response.isSuccessful())
						systemResponse("Saved backup " + jFileChooserSaveBackup.getSelectedFile());
					else
						systemResponse("Backup failed: " + response.getMessage());
					response.showMessageDialog();
					return null;
				}
			}).execute();
		}
	}
	
	private JButton jButtonClearInput;
	private JButton jButtonClearOutput;
	private JButton jButtonCopyToInput;
	private JButton jButtonLoadCommand;
	private JButton jButtonNextCommand;
	private JButton jButtonPreviousCommand;
	private JButton jButtonRun;
	private JButton jButtonSaveCurrent;
	private JButton jButtonSaveHistory;
	private JButton jButtonSaveOutputText;
	private JButton jButtonSaveOutputFormatted;
	private JButton jButtonBackup;
	private JCheckBox jCheckBoxAutoclear;
	private JCheckBox jCheckBoxCopyToOutput;
	private JCheckBox jCheckBoxEnhanced;
	private JCheckBox jCheckBoxSuppressOk;
	private JCheckBox jCheckBoxWrapInput;
	private JCheckBox jCheckBoxWrapOutput;
	private JFileChooser jFileChooserLoad;
	private JFileChooser jFileChooserSave;
	private JFileChooser jFileChooserSaveOutputText;
	private JFileChooser jFileChooserSaveOutputFormatted;
	private JFileChooser jFileChooserSaveBackup;
	private JLabel jLabelCaretPosition;
	private JLabel jLabelRunning;
	private JPanel jPanelBottom;
	private JPanel jPanelInput;
	private JPanel jPanelOutput;
	private JScrollPane jScrollPaneInput;
	private JScrollPane jScrollPaneOutput;
	private JSplitPane jSplitPaneMain;
	private JTextArea jTextAreaInput;
	private JToolBar jToolBarInput;
	private JToolBar jToolBarOutput;
	private JTextPane jTextAreaOutputFormatted;
	private JTextArea jTextAreaOutputPlain;
	
}
