package ca.mb.armchair.rel3.dbrowser.ui;

public class Version {
	public static String getVersion() {
		return "2.09";
	}
}
