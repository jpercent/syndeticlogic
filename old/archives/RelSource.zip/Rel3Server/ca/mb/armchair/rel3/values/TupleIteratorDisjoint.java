package ca.mb.armchair.rel3.values;

import java.util.TreeSet;
import java.util.NoSuchElementException;

import ca.mb.armchair.rel3.exceptions.ExceptionSemantic;

/** A TupleIteratorUnique is a TupleIterator that throws an exception if it encounters duplicate ValueTuple's. */
public class TupleIteratorDisjoint extends TupleIterator {

	private TupleIterator source;
	private TreeSet<ValueTuple> tupleSet;
	
	// TODO - modify TupleIteratorDisjoint to prevent out-of-memory on high-cardinality relations
	public TupleIteratorDisjoint(TupleIterator source) {
		this.source = source;
		tupleSet = new TreeSet<ValueTuple>();
	}
	
	@Override
	public boolean hasNext() {
		return source.hasNext();
	}

	@Override
	public ValueTuple next() {
		if (hasNext()) {
			ValueTuple tuple = source.next();
			if (tupleSet.contains(tuple))
				throw new ExceptionSemantic("Requirement that tuples be disjoint has been violated.");
			tupleSet.add(tuple);
			return tuple;
		}
		throw new NoSuchElementException();
	}

	public void close() {
		source.close();
	}
}
