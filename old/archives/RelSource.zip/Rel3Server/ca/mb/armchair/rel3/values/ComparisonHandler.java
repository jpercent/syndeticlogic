package ca.mb.armchair.rel3.values;

import java.io.Serializable;
import java.util.Comparator;

/*
 * Custom Comparator used by TreeSet in ValueRelation and ValueRelationLiteral.
 */
class ComparisonHandler implements Serializable, Comparator<ValueTuple> {
	private static final long serialVersionUID = 1L;
	
	@Override
	public int compare(ValueTuple v1, ValueTuple v2) {
		return ((Value)v1).compareTo(v1.getGenerator(), (Value)v2);
	}
}
