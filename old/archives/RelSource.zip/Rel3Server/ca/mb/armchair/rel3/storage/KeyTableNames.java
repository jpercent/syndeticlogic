package ca.mb.armchair.rel3.storage;

import java.io.Serializable;

/** A table (Database) and associated index (also DatabaseS) names. */
class KeyTableNames implements Serializable {
	private final static long serialVersionUID = 0;
	
	private String[] names;
	
	KeyTableNames(int tableCount) {
		names = new String[tableCount];
	}

	String getName(int i) {
		return names[i];
	}
	
	void setName(int i, String name) {
		names[i] = name;
	}
	
	int size() {
		return names.length;
	}
}
