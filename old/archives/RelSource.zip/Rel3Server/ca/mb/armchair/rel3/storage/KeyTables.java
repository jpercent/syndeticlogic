package ca.mb.armchair.rel3.storage;

import com.sleepycat.je.*;

/** A table (Database) and associated indexes (also DatabaseS) */
class KeyTables {

	private Database[] tables;
	
	KeyTables(int tableCount) throws DatabaseException {
		tables = new Database[tableCount];
	}

	Database getDatabase(int i) {
		return tables[i];
	}
	
	void setDatabase(int i, Database table) throws DatabaseException {
		tables[i] = table;
	}
	
	KeyTableNames getDatabaseName() throws DatabaseException {
		KeyTableNames name = new KeyTableNames(tables.length);
		for (int i=0; i<name.size(); i++)
			name.setName(i, tables[i].getDatabaseName());
		return name;
	}
	
	int size() {
		return tables.length;
	}
}
