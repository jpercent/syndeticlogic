package ca.mb.armchair.rel3.types;

import ca.mb.armchair.rel3.exceptions.ExceptionSemantic;

/** Abstract base class for TypeTuple and TypeRelation. */
public abstract class TypeHeading extends TypeAbstract {

	protected Heading heading;
	
	/** Create new TypeHeading from a given Heading. */
	public TypeHeading(Heading heading) {
		this.heading = heading;
	}

	public boolean requiresReformatOf(Type type) {
		if (!(type instanceof TypeHeading))
			throw new ExceptionSemantic("Expected something with a heading but got a " + type + " in an operator invocation.");
		return heading.requiresReformatOf(((TypeHeading)type).getHeading());
	}
	
	public boolean canAccept(Type type) {
		if (!(type instanceof TypeHeading))
			throw new ExceptionSemantic("Expected something with a heading but got a " + type + " in an operator invocation.");
		return heading.canAccept(((TypeHeading)type).getHeading());
	}
	
	public Heading getHeading() {
		return heading;
	}
}
