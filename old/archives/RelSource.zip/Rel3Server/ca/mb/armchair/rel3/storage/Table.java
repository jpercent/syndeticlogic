package ca.mb.armchair.rel3.storage;

import com.sleepycat.je.*;

import java.util.NoSuchElementException;

import ca.mb.armchair.rel3.values.*; 
import ca.mb.armchair.rel3.exceptions.*;
import ca.mb.armchair.rel3.generator.Generator;
import ca.mb.armchair.rel3.generator.SelectAttributes;
import ca.mb.armchair.rel3.types.Heading;
import ca.mb.armchair.rel3.types.AttributeMap;

/** An updatable collection of ValueTupleS; a wrapper around Berkeley DB's "Database". */
public abstract class Table {

	private RelDatabase database;
	private RelvarHeading headingDefinition;
	private AttributeMap[] keyMaps;
	
	public Table(RelDatabase database, RelvarHeading headingDefinition) {
		this.database = database;
		this.headingDefinition = headingDefinition;
		keyMaps = new AttributeMap[headingDefinition.getKeyCount()];
		for (int keyNumber=0; keyNumber<headingDefinition.getKeyCount(); keyNumber++) {
			SelectAttributes keyAttributes = headingDefinition.getKey(keyNumber); 
			Heading sourceHeading = headingDefinition.getHeading();
			Heading targetHeading = sourceHeading.project(keyAttributes);
			keyMaps[keyNumber] = new AttributeMap(targetHeading, sourceHeading);
		}
	}
	
	public RelvarHeading getHeadingDefinition() {
		return headingDefinition;
	}
	
	protected abstract KeyTables getTable(Transaction txn) throws DatabaseException;
	
	public RelDatabase getDatabase() {
		return database;
	}
	
	private DatabaseEntry getKeyValueFromTuple(Generator generator, ValueTuple tuple, int keyNumber) {
		DatabaseEntry theKey = new DatabaseEntry();
		if (headingDefinition.getKeyCount() == 0)
			database.getTupleBinding().objectToEntry(tuple, theKey);
		else {
			ValueTuple keyTuple = keyMaps[keyNumber].project(generator, tuple);
			database.getTupleBinding().objectToEntry(keyTuple, theKey);
		}
		return theKey;
	}
	
	void insertTuple(Generator generator, KeyTables table, Transaction txn, ValueTuple tuple, String description) throws DatabaseException {
		DatabaseEntry theData = new DatabaseEntry();
		database.getTupleBinding().objectToEntry(tuple, theData);
		// Put it in the database.
		for (int i=0; i<table.size(); i++) {
			Database tab = table.getDatabase(i);
			DatabaseEntry entry = (i == 0) ? theData : database.getKeyTableEntry();
			if (tab.putNoOverwrite(txn, getKeyValueFromTuple(generator, tuple, i), entry) == OperationStatus.KEYEXIST)
				throw new ExceptionSemantic(description + " tuple would violate uniqueness constraint of KEY {" + headingDefinition.getKey(i) + "}");
		}
	}
	
	public void insert(final Generator generator, final ValueTuple tuple) {		
    	try {
	    	(new TransactionRunner() {
	    		public Object run(Transaction txn) throws Throwable {
	    			insertTuple(generator, getTable(txn), txn, tuple, "Inserting");
    	    		return null;
	    		}
	    	}).execute(database);
    	} catch (ExceptionSemantic se) {
    		throw se;
    	} catch (Throwable t) {
			throw new ExceptionSemantic("Table: insert tuple failed: " + t.getMessage());
    	}
	}
	
	public long insert(final Generator generator, final ValueRelation relation) {
    	try {
	    	return ((Long)(new TransactionRunner() {
	    		public Object run(Transaction txn) throws Throwable {
	    			// use of temporary storage prevents problems with deadlock or infinite iteration if we insert a relvar into itself
	    	    	TempStorageTuples tmp = new TempStorageTuples(database);
	    			long insertCount = 0;
	    	    	try {
		    			KeyTables table = getTable(txn);
		    			TupleIterator iterator = relation.iterator(generator);
		    			try {
		    				while (iterator.hasNext()) {
		    					tmp.put(txn, iterator.next());
		    					insertCount++;
		    				}
		    			} finally {
		    				iterator.close();
		    			}
		    			iterator = tmp.keys();
		    			try {
		    				while (iterator.hasNext()) {
				    			ValueTuple tuple = iterator.next();
		    					insertTuple(generator, table, txn, tuple, "Inserting");
		    				}
		    			} finally {
		    				iterator.close();
		    			}
	    	    	} finally {
	    	    		tmp.close();
	    	    	}
    	    		return new Long(insertCount);
	    		}
	    	}).execute(database)).longValue();
    	} catch (ExceptionSemantic se) {
    		throw se;
    	} catch (Throwable t) {
    		t.printStackTrace();
			throw new ExceptionSemantic("Table: insert relation failed: " + t.getMessage());
    	}
	}
	
	public long getCardinality() {
		try {
	    	return ((Long)(new TransactionRunner() {
	    		public Object run(Transaction txn) throws Throwable {
	    			return new Long(getTable(txn).getDatabase(0).count());
	    		}
	    	}).execute(database)).longValue();
    	} catch (ExceptionSemantic se) {
    		throw se;
		} catch (Throwable de) {
    		de.printStackTrace();
    		throw new ExceptionFatal("Table: getCardinality failed: " + de.getMessage());
		}
	}
	
	/** Obtain tuple value given a key.  Return null if not found. */
	public ValueTuple getTupleForKey(final Generator generator, final ValueTuple tuple) {
    	try {
	    	return ((ValueTuple)(new TransactionRunner() {
	    		public Object run(Transaction txn) throws Throwable {
	    		    DatabaseEntry foundData = new DatabaseEntry();	
    				if (getTable(txn).getDatabase(0).get(txn, getKeyValueFromTuple(generator, tuple, 0), foundData, LockMode.READ_COMMITTED) == OperationStatus.SUCCESS)
						return (ValueTuple)database.getTupleBinding().entryToObject(foundData);
    				return null;
	    		}
	    	}).execute(database));
    	} catch (ExceptionSemantic se) {
    		throw se;
    	} catch (Throwable t) {
    		t.printStackTrace();
    		throw new ExceptionFatal("Table: getTupleForKey failed: " + t.getMessage());
    	}		
	}
	
	public boolean contains(final Generator generator, final ValueTuple tuple) {
    	try {
	    	return ((Boolean)(new TransactionRunner() {
	    		public Object run(Transaction txn) throws Throwable {
	    		    DatabaseEntry foundData = new DatabaseEntry();	
    				if (getTable(txn).getDatabase(0).get(txn, getKeyValueFromTuple(generator, tuple, 0), foundData, LockMode.READ_COMMITTED) == OperationStatus.SUCCESS)
    					return new Boolean(true);
    				return new Boolean(false);
	    		}
	    	}).execute(database)).booleanValue();
    	} catch (ExceptionSemantic se) {
    		throw se;
    	} catch (Throwable t) {
    		t.printStackTrace();
    		throw new ExceptionFatal("Table: contains failed: " + t.getMessage());
    	}
	}

	// Delete all tuples
	private void purge(Transaction txn) throws DatabaseException {
		KeyTables tables = getTable(txn);
		for (int i=0; i<tables.size(); i++) {
			Cursor cursor = tables.getDatabase(i).openCursor(txn, null);
			try {
			    DatabaseEntry foundKey = new DatabaseEntry();
			    DatabaseEntry foundData = new DatabaseEntry();	
				while (cursor.getNext(foundKey, foundData, LockMode.RMW) == OperationStatus.SUCCESS)
					cursor.delete();
			} finally {
				cursor.close();
			}
		}
	}
	
	// Delete all tuples
	public void purge() {
    	try {
	    	(new TransactionRunner() {
	    		public Object run(Transaction txn) throws Throwable {
	    			purge(txn);
    	    		return null;
	    		}
	    	}).execute(database);
    	} catch (ExceptionSemantic se) {
    		throw se;
    	} catch (Throwable t) {
    		t.printStackTrace();
			throw new ExceptionFatal("Table: purge failed: " + t.getMessage());
    	}
	}

	// Delete given tuple.
	public void delete(final Generator generator, final ValueTuple tuple) {
    	try {
	    	(new TransactionRunner() {
	    		public Object run(Transaction txn) throws Throwable {
	    			KeyTables tables = getTable(txn);
	    			for (int i=0; i<tables.size(); i++)
	    				tables.getDatabase(i).delete(txn, getKeyValueFromTuple(generator, tuple, i));
    	    		return null;
	    		}
	    	}).execute(database);
    	} catch (ExceptionSemantic se) {
    		throw se;
    	} catch (Throwable t) {
    		t.printStackTrace();
			throw new ExceptionFatal("Table: delete tuple failed: " + t.getMessage());
    	}
	}
	
	// Delete selected tuples
	public long delete(final Generator generator, final TupleFilter filter) {
    	try {
	    	return ((Long)(new TransactionRunner() {
	    		public Object run(Transaction txn) throws Throwable {
	    			KeyTables tables = getTable(txn);
    				Cursor cursor = tables.getDatabase(0).openCursor(txn, null);
    				long deleteCount = 0;
    				try {
    				    DatabaseEntry foundKey = new DatabaseEntry();
    				    DatabaseEntry foundData = new DatabaseEntry();	
    					while (cursor.getNext(foundKey, foundData, LockMode.RMW) == OperationStatus.SUCCESS) {
    						ValueTuple tuple = (ValueTuple)database.getTupleBinding().entryToObject(foundData);
    						if (filter.filter(tuple)) {
    							cursor.delete();
    							for (int i=1; i<tables.size(); i++)
    								tables.getDatabase(i).delete(txn, getKeyValueFromTuple(generator, tuple, i));
    							deleteCount++;
    						}
    					}
    				} finally {
    					cursor.close();
    				}
    	    		return new Long(deleteCount);
	    		}
	    	}).execute(database)).longValue();
    	} catch (ExceptionSemantic se) {
    		throw se;
    	} catch (Throwable t) {
    		t.printStackTrace();
			throw new ExceptionFatal("Table: delete tuples failed: " + t.getMessage());
    	}		
	}
	
	// Update selected tuples using a given TupleMap
	public long update(final Generator generator, final TupleFilter whereFilter, final TupleMap updateMap) {
    	try {
	    	return ((Long)(new TransactionRunner() {
	    		public Object run(Transaction txn) throws Throwable {
	    			TempStorageTuples insertionTemporaryTable = new TempStorageTuples(database);
	    			long updateCount = 0;
	    			try {
		    			KeyTables tables = getTable(txn);
	    			    DatabaseEntry foundKey = new DatabaseEntry();
	    			    DatabaseEntry foundData = new DatabaseEntry();	
		    			Cursor cursor = tables.getDatabase(0).openCursor(txn, null);
		    			try {
		    				while (cursor.getNext(foundKey, foundData, LockMode.RMW) == OperationStatus.SUCCESS) {
		    					ValueTuple tuple = (ValueTuple)database.getTupleBinding().entryToObject(foundData);
		    					if (whereFilter.filter(tuple)) {
		    						ValueTuple newTuple = updateMap.map(tuple);
		    						cursor.delete();
		    						for (int i=1; i<tables.size(); i++)
		    							tables.getDatabase(i).delete(txn, getKeyValueFromTuple(generator, tuple, i));	    					
		    						insertionTemporaryTable.put(txn, newTuple);
									updateCount++;
		    					}
		    				}
		    			} finally {
		    				cursor.close();
		    			}		
		    			TupleIterator iterator = insertionTemporaryTable.keys();
		    			try {
		    				while (iterator.hasNext())
		    					insertTuple(generator, tables, txn, iterator.next(), "Updating");
		    			} finally {
		    				iterator.close();
		    			}
	    			} finally {
	    				insertionTemporaryTable.close();
	    			}
    	    		return new Long(updateCount);
	    		}
	    	}).execute(database)).longValue();
    	} catch (ExceptionSemantic se) {
    		throw se;
    	} catch (Throwable t) {
    		t.printStackTrace();
			throw new ExceptionFatal("Table: update failed: " + t.getMessage());
    	}		
	}
	
	// Update all tuples using a given TupleMap
	public long update(final Generator generator, final TupleMap map) {
		return update(generator, new TupleFilter() {
			public boolean filter(ValueTuple tuple) {
				return true;
			}
		}, map);
	}
	
	// Get a TupleIterator
	public TupleIterator iterator(final Generator generator) {
	    return new TupleIterator() {
	    	RelTransaction txn = null;
			Cursor cursor = null;
		    DatabaseEntry foundKey = new DatabaseEntry();
		    DatabaseEntry foundData = new DatabaseEntry();	
		    ValueTuple current = null;
		    boolean atEnd = false;
			public boolean hasNext() {
				if (current != null)
					return true;
				if (atEnd)
					return false;
				try {
					if (cursor == null) {
						txn = database.beginTransaction();
						cursor = getTable(txn.getTransaction()).getDatabase(0).openCursor(txn.getTransaction(), null);
					}
					if (cursor.getNext(foundKey, foundData, LockMode.DEFAULT) == OperationStatus.SUCCESS) {
						current = (ValueTuple)database.getTupleBinding().entryToObject(foundData);
						current.loaded(generator);
						return true;
					} else
						atEnd = true;
				} catch (DatabaseException exp) {
		    		exp.printStackTrace();
					throw new ExceptionFatal("Table: Unable to get next tuple: " + exp.getMessage());					
				}
				return false;
			}
			public ValueTuple next() {
				if (hasNext())
					try {
						return current;
					} finally {
						current = null;
					}
				throw new NoSuchElementException();
			}
			public void close() {
				try {
					if (cursor != null) {
						cursor.close();
						database.commitTransaction(txn);
					}
				} catch (DatabaseException exp) {
		    		exp.printStackTrace();
					throw new ExceptionFatal("Table: Unable to close cursor: " + exp.getMessage());
				}
			}
		};
	}
		
}
