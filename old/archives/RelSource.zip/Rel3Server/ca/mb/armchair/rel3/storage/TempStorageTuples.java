package ca.mb.armchair.rel3.storage;

import java.util.NoSuchElementException;

import com.sleepycat.je.Cursor;
import com.sleepycat.je.Database;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.LockMode;
import com.sleepycat.je.OperationStatus;
import com.sleepycat.je.Transaction;

import ca.mb.armchair.rel3.exceptions.ExceptionFatal;
import ca.mb.armchair.rel3.exceptions.ExceptionSemantic;
import ca.mb.armchair.rel3.generator.Generator;
import ca.mb.armchair.rel3.values.TupleIterator;
import ca.mb.armchair.rel3.values.ValueBoolean;
import ca.mb.armchair.rel3.values.ValueTuple;

// TODO - improve performance here by only using disk storage when number of tuples exceeds a specified limit
public class TempStorageTuples {

	private Database storage;
	private RelDatabase database;
	
	public TempStorageTuples(RelDatabase db) {
		database = db;
		storage = database.createTempStorage();
	}
	
	public void close() {
		database.destroyTempStorage(storage);
	}
	
	public void put(Transaction txn, ValueTuple keyTuple) throws DatabaseException {
		DatabaseEntry theData = new DatabaseEntry();
		database.getTupleBinding().objectToEntry(keyTuple, theData);
		storage.put(txn, theData, database.getKeyTableEntry());
	}
	
	public void put(final ValueTuple keyTuple) {
		try {
	    	(new TransactionRunner() {
	    		public Object run(Transaction txn) throws Throwable {
	    			put(txn, keyTuple);
	    			return null;
	    		}
	    	}).execute(database);
		} catch (ExceptionSemantic se) {
			throw se;
		} catch (Throwable t) {
			throw new ExceptionFatal("TempStorageTuples: put tuple failed: " + t.getMessage());
		}
	}
	
	public void put(Generator generator, Transaction txn, ValueTuple keyTuple, ValueTuple valueTuple) throws DatabaseException {
		DatabaseEntry theKey = new DatabaseEntry();
		database.getTupleBinding().objectToEntry((ValueTuple)keyTuple.getSerializableClone(generator), theKey);
		DatabaseEntry theData = new DatabaseEntry();
		database.getTupleBinding().objectToEntry((ValueTuple)valueTuple.getSerializableClone(generator), theData);
		storage.put(txn, theKey, theData);	
	}
	
	public void put(final Generator generator, final ValueTuple keyTuple, final ValueTuple valueTuple) {
		try {
	    	(new TransactionRunner() {
	    		public Object run(Transaction txn) throws Throwable {
	    			put(generator, txn, keyTuple, valueTuple);
	    			return null;
	    		}
	    	}).execute(database);
		} catch (ExceptionSemantic se) {
			throw se;
		} catch (Throwable t) {
			throw new ExceptionFatal("TempStorageTuples: put " + valueTuple + " with key " + keyTuple + " failed: " + t.getMessage());
		}
	}

	public boolean containsKey(Transaction txn, ValueTuple keyTuple) throws DatabaseException {
		DatabaseEntry theKey = new DatabaseEntry();
		database.getTupleBinding().objectToEntry(keyTuple, theKey);
	    DatabaseEntry foundData = new DatabaseEntry();	
		return (storage.get(txn, theKey, foundData, LockMode.READ_COMMITTED) == OperationStatus.SUCCESS);
	}
	
	public boolean containsKey(final Generator generator, final ValueTuple keyTuple) {
		try {
	    	return ((ValueBoolean)(new TransactionRunner() {
	    		public Object run(Transaction txn) throws Throwable {
	    			return ValueBoolean.select(generator, containsKey(txn, keyTuple));
	    		}
	    	}).execute(database)).booleanValue();
		} catch (ExceptionSemantic se) {
			throw se;
		} catch (Throwable t) {
			throw new ExceptionFatal("TempStorageTuples: containsKey failed: " + t.getMessage());
		}		
	}
	
	public ValueTuple getValue(Transaction txn, ValueTuple keyTuple) throws DatabaseException {
		DatabaseEntry theKey = new DatabaseEntry();
		database.getTupleBinding().objectToEntry(keyTuple, theKey);
	    DatabaseEntry foundData = new DatabaseEntry();	
		if (storage.get(txn, theKey, foundData, LockMode.READ_COMMITTED) != OperationStatus.SUCCESS)
			return null;
		return (ValueTuple)database.getTupleBinding().entryToObject(foundData);
	}
	
	public ValueTuple getValue(final ValueTuple keyTuple) {
		try {
	    	return (ValueTuple)(new TransactionRunner() {
	    		public Object run(Transaction txn) throws Throwable {
	    			return getValue(txn, keyTuple);
	    		}
	    	}).execute(database);
		} catch (ExceptionSemantic se) {
			throw se;
		} catch (Throwable t) {
			throw new ExceptionFatal("TempStorageTuples: getValue failed: " + t);
		}		
	}
	
	private abstract class StorageIterator extends TupleIterator {
    	protected RelTransaction txn = null;
		protected Cursor cursor = null;
	    protected ValueTuple current = null;
	    
	    public abstract ValueTuple getCurrent(DatabaseEntry foundKey, DatabaseEntry foundData);
	    
		public boolean hasNext() {
			if (current != null)
				return true;
			try {
				if (cursor == null) {
					txn = database.beginTransaction();
					cursor = storage.openCursor(txn.getTransaction(), null);
				}
			    DatabaseEntry foundKey = new DatabaseEntry();
			    DatabaseEntry foundData = new DatabaseEntry();	
				if (cursor.getNext(foundKey, foundData, LockMode.DEFAULT) == OperationStatus.SUCCESS) {
					current = getCurrent(foundKey, foundData); 
					return true;
				}
			} catch (DatabaseException exp) {
				throw new ExceptionFatal("TempStorageTuples: Unable to get next tuple: " + exp.getMessage());					
			}
			return false;
		}
		
		public ValueTuple next() {
			if (hasNext())
				try {
					return current;
				} finally {
					current = null;
				}
			throw new NoSuchElementException();
		}
		
		public void close() {
			try {
				if (cursor != null) {
					cursor.close();
					database.commitTransaction(txn);
				}
			} catch (DatabaseException exp) {
				throw new ExceptionFatal("TempStorageTuples: Unable to close cursor: " + exp.getMessage());
			}
		}		
	}
	
	// Get a TupleIterator on keys
	public TupleIterator keys() {
	    return new StorageIterator() {
	    	public ValueTuple getCurrent(DatabaseEntry foundKey, DatabaseEntry foundData) {
	    		return (ValueTuple)database.getTupleBinding().entryToObject(foundKey);	    		
	    	}
		};
	}
	
	// Get a TupleIterator on values
	public TupleIterator values() {
	    return new StorageIterator() {
	    	public ValueTuple getCurrent(DatabaseEntry foundKey, DatabaseEntry foundData) {
	    		return (ValueTuple)database.getTupleBinding().entryToObject(foundData);	    		
	    	}
		};
	}
	
	// Get a TupleIterator on values which iterates all values for a given Key
	public TupleIterator keySearch(final Generator generator, final ValueTuple key) {
	    return new StorageIterator() {
	    	public boolean hasNext() {
	    		if (current != null)
	    			return true;
	    		try {
	    		    DatabaseEntry foundKey = new DatabaseEntry();
	    		    DatabaseEntry foundData = new DatabaseEntry();	
	    			if (cursor == null) {
	    				txn = database.beginTransaction();
	    				cursor = storage.openCursor(txn.getTransaction(), null);
	    				database.getTupleBinding().objectToEntry((ValueTuple)key.getSerializableClone(generator), foundKey);
	    				if (cursor.getSearchKey(foundKey, foundData, LockMode.DEFAULT) == OperationStatus.SUCCESS) {
		    				current = getCurrent(foundKey, foundData); 
	    					return true;
	    				}
	    				return false;
	    			} else if (cursor.getNextDup(foundKey, foundData, LockMode.DEFAULT) == OperationStatus.SUCCESS) {
	    				current = getCurrent(foundKey, foundData); 
	    				return true;
	    			}
	    		} catch (DatabaseException exp) {
	    			throw new ExceptionFatal("TempStorageTuples: Unable to get next tuple: " + exp.getMessage());					
	    		}
	    		return false;
	    	}
	    	public ValueTuple getCurrent(DatabaseEntry foundKey, DatabaseEntry foundData) {
	    		return (ValueTuple)database.getTupleBinding().entryToObject(foundData);	    		
	    	}
		};
	}
	
}
