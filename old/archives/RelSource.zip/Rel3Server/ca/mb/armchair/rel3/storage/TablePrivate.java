package ca.mb.armchair.rel3.storage;


import com.sleepycat.je.*;

public class TablePrivate extends Table {

	private KeyTables rawTable;
	
	public TablePrivate(RelDatabase database, KeyTables rawTable, RelvarHeading headingDefinition) {
		super(database, headingDefinition);
		setTable(rawTable);
	}
	
	public void setTable(KeyTables rawTable) {
		this.rawTable = rawTable;
	}
	
	@Override
	protected KeyTables getTable(Transaction txn) {
		return rawTable;
	}

}
