package ca.mb.armchair.rel3.storage;

import ca.mb.armchair.rel3.generator.Generator;
import ca.mb.armchair.rel3.values.TupleFilter;
import ca.mb.armchair.rel3.values.ValueRelation;
import ca.mb.armchair.rel3.values.ValueTuple;
import ca.mb.armchair.rel3.values.TupleIterator;
import ca.mb.armchair.rel3.vm.Context;
import ca.mb.armchair.rel3.vm.Operator;

public interface Relvar {
	abstract public long getCardinality(Generator generator);

	abstract public boolean contains(Generator generator, ValueTuple tuple);

	abstract public void setValue(ValueRelation relation);

	abstract public long insert(Generator generator, ValueTuple tuple);

	abstract public long insert(Generator generator, ValueRelation relation);

	abstract public void purge();

	// Delete selected tuples
	abstract public long delete(Context context, Operator whereTupleOperator);

	// Delete selected tuples
	abstract public long delete(Generator generator, TupleFilter filter);
	
	// Update all tuples using a given update operator
	abstract public long update(Context context, Operator updateTupleOperator);

	// Update selected tuples using a given update operator
	abstract public long update(Context context, Operator whereTupleOperator,
			Operator updateTupleOperator);

	abstract public TupleIterator iterator(Generator generator);
}