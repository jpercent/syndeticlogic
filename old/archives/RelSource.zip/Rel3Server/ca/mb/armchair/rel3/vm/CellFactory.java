package ca.mb.armchair.rel3.vm;

public interface CellFactory {
	public Cell getNewCell();
}
