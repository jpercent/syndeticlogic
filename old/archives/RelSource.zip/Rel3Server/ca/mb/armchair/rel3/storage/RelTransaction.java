package ca.mb.armchair.rel3.storage;

import com.sleepycat.je.*;

import ca.mb.armchair.rel3.exceptions.ExceptionFatal;

class RelTransaction {
	
	private int referenceCount;
	private Transaction transaction;
	private boolean aborting;
	private boolean aborted;
	
	RelTransaction(Transaction txn) {
		transaction = txn;
		referenceCount = 1;
		aborting = false;
		aborted = false;
	//	System.out.println("TRANSACTION: start: " + transaction);
	//	(new ExceptionFatal("")).printStackTrace();
	}
	
	Transaction getTransaction() {
		return transaction;
	}
	
	void addReference() {
		referenceCount++;
	}
	
	int getReferenceCount() {
		return referenceCount;
	}
	
	void abort() {
		aborting = true;
		if (--referenceCount > 0)
			return;
		try {
			transaction.abort();
			aborted = true;
	//		System.out.println("TRANSACTION: abort: " + transaction);
		} catch (DatabaseException de) {
			throw new ExceptionFatal("RelTransaction: abort failed: " + de);
		}
	}
	
	void commit() {
		if (--referenceCount > 0)
			return;
		try {
			if (aborting && !aborted) {
				transaction.abort();
				aborted = true;
	//			System.out.println("TRANSACTION: abort: " + transaction);
			}
			else {
				transaction.commit();
	//			System.out.println("TRANSACTION: commit: " + transaction);
			}
		} catch (DatabaseException de) {
			throw new ExceptionFatal("RelTransaction: commit failed: " + de);
		}
	}
	
	public String toString() {
		return transaction.toString();
	}
}
