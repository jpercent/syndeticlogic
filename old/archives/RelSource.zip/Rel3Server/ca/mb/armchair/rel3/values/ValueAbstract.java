package ca.mb.armchair.rel3.values;
 
import java.io.PrintStream;

import ca.mb.armchair.rel3.types.*;
import ca.mb.armchair.rel3.vm.Context;
import ca.mb.armchair.rel3.exceptions.ExceptionSemantic;
import ca.mb.armchair.rel3.generator.Generator;

public abstract class ValueAbstract implements Value {

	private static final long serialVersionUID = 1L;
	
	private transient Generator generator;

	public ValueAbstract(Generator generator) {
		this.generator = generator;
	}
	
	public void loaded(Generator generator) {
		this.generator = generator;
	}
	
	protected Generator getGenerator() {
		return generator;
	}
	
	/** Output this Value to a PrintStream. */
	public void toStream(Generator generator, Context context, Type type, PrintStream p, int depth) {
		if (depth > 0)
			p.print(toParsableString(type));
		else
			p.print(toString(type));
	}
	
	public boolean equals(Object v) {
		return (compareTo((Value)v) == 0);
	}
	
	public int compareTo(Value v) {
		return compareTo(generator, v);
	}
	
	public String toParsableString(Type type) {
		return toString();
	}
	
	public String toString(Type type) {
		return toString();
	}
	
	/** Obtain a serializable clone of this value. */
	public Value getSerializableClone(Generator generator) {
		return this;
	}
		
	/** Convert this to a primitive boolean. */
	public boolean booleanValue() {
		throw new ExceptionSemantic("Cannot convert " + getTypeName() + " to BOOLEAN.");
	}

	/** Convert this to a primitive long. */
	public long longValue() {
		throw new ExceptionSemantic("Cannot convert " + getTypeName() + " to INTEGER.");
	}

	/** Convert this to a primitive double. */
	public double doubleValue() {
		throw new ExceptionSemantic("Cannot convert " + getTypeName() + " to RATIONAL.");
	}

	/** Convert this to a primitive string. */
	public String stringValue() {
		throw new ExceptionSemantic("Cannot convert " + getTypeName() + " to CHARACTER.");
	}
}
