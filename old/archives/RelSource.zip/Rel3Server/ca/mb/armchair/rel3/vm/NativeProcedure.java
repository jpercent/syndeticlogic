package ca.mb.armchair.rel3.vm;

import ca.mb.armchair.rel3.values.Value;

public abstract class NativeProcedure {
	public abstract void execute(Value arguments[]);
}
