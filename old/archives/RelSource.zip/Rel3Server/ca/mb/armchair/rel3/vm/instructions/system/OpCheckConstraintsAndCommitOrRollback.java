/**
 * 
 */
package ca.mb.armchair.rel3.vm.instructions.system;

import ca.mb.armchair.rel3.vm.Context;
import ca.mb.armchair.rel3.vm.Instruction;
import ca.mb.armchair.rel3.vm.VirtualMachine;
import ca.mb.armchair.rel3.exceptions.*;

public final class OpCheckConstraintsAndCommitOrRollback extends Instruction {
	public final void execute(Context context) {
		VirtualMachine vm = context.getVirtualMachine();
		String failedConstraint = vm.getRelDatabase().checkConstraints(vm.getPrintStream());
		if (failedConstraint != null) {
			vm.getRelDatabase().rollbackTransaction();
			vm.clearTupleUpdateNotices();
			throw new ExceptionSemantic("Update will cause CONSTRAINT " + failedConstraint + " to fail.");
		}
		else
			vm.getRelDatabase().commitTransaction();
	}
}
