package ca.mb.armchair.rel3.values;

import java.io.PrintStream;
import java.util.*;

import ca.mb.armchair.rel3.exceptions.*;
import ca.mb.armchair.rel3.generator.Generator;
import ca.mb.armchair.rel3.types.*;
import ca.mb.armchair.rel3.vm.Context;

public class ValueArray extends ValueAbstract {

	private static final long serialVersionUID = 0;

	private ArrayList<ValueTuple> values;
	private ValueRelation relation;

	/** Create a new ARRAY. */
	public ValueArray(Generator generator) {
		super(generator);
		values = new ArrayList<ValueTuple>();
		relation = null;
	}
	
	/** Create a new ARRAY given an ArrayList. */
	ValueArray(Generator generator, ArrayList<ValueTuple> values) {
		super(generator);
		this.values = values;
		relation = null;
	}
	
	/** Create a new ARRAY as a wrapper around a ValueRelation. */
	ValueArray(Generator generator, ValueRelation relation) {
		super(generator);
		this.values = null;
		this.relation = relation;
	}
	
	private void convertToArray(Generator generator) {
		TupleIterator iterator = relation.iterator(generator);
		try {
			values = new ArrayList<ValueTuple>();
			while (iterator.hasNext())
				values.add(iterator.next());
			relation = null;
		} finally {
			iterator.close();
		}
	}
	
	public Value project(final Generator generator, final AttributeMap map) {
		return new ValueArray(generator) {
			private final static long serialVersionUID = 0;

			public TupleIterator iterator(final Generator generator) {
				return new TupleIterator() {
					TupleIterator tuples = ValueArray.this.iterator(generator);

					public boolean hasNext() {
						return tuples.hasNext();
					}

					public ValueTuple next() {
						return (ValueTuple)tuples.next().project(generator, map);
					}
					
					public void close() {
						tuples.close();
					}					
				};
			}
		};
	}

	public ValueRelation toRelation(final Generator generator) {
		return new ValueRelation(generator) {
			private final static long serialVersionUID = 0;

			public TupleIterator newIterator(Generator generator) {
				return new TupleIteratorUnique(ValueArray.this.iterator(generator));
			}
		};
	}
	
	public String getTypeName() {
		return "ARRAY";
	}

	public long getCount(Generator generator) {
		if (values == null)
			return relation.getCardinality(generator);
		else
			return values.size();
	}

	private void checkIndexOutOfBounds(int index) {
		if (index >= values.size())
			if (values.size() == 0)
				throw new ExceptionSemantic("Array index " + index + " is out of bounds; array is empty.");				
			else
				throw new ExceptionSemantic("Array index " + index + " is out of bounds; highest index is " + (values.size() - 1) + ".");
		else if (index < 0)
			throw new ExceptionSemantic("Array index " + index + " is out of bounds; it's less than 0.");					
	}
	
	public Value get(Generator generator, int index) {
		if (values == null)
			convertToArray(generator);
		checkIndexOutOfBounds(index);
		return values.get(index);
	}

	public void set(Generator generator, int index, ValueTuple value) {
		if (values == null)
			convertToArray(generator);
		checkIndexOutOfBounds(index);
		values.set(index, value);
	}
	
	public void append(Generator generator, ValueTuple value) {
		if (values == null)
			convertToArray(generator);
		values.add(value);
	}
	
	public TupleIterator iterator(Generator generator) {
		if (values == null)
			return relation.iterator(generator);
		else
			return new TupleIterator() {
				Iterator<ValueTuple> iterator = values.iterator();
				public boolean hasNext() {
					return iterator.hasNext();
				}
				public ValueTuple next() {
					return (ValueTuple)iterator.next();
				}
				public void close() {
				}
			};
	}

	private void toStreamFromRelation(Generator generator, Context context, Type type, PrintStream p, int depth) {
		TypeTuple tupleType = ((TypeArray)type).getElementType();
		Heading heading = tupleType.getHeading();
		if (depth == 0)
			p.print("ARRAY " + heading + " {");
		else
			p.print("ARRAY {");
		long count = 0;
		TupleIterator iterator = relation.iterator(generator);
		try {
			while (iterator.hasNext()) {
				ValueTuple tuple = iterator.next();
				if (count++ > 0)
					p.print(',');
				p.print("\n\t");
				tuple.toStream(generator, context, tupleType, p, depth + 1);
			}
		} finally {
			iterator.close();
		}
		p.print("\n}");		
	}
	
	private void toStreamFromArray(Generator generator, Context context, Type type, PrintStream p, int depth) {
		TypeTuple elementType = ((TypeArray)type).getElementType();
		if (depth == 0) {
			Heading heading = ((TypeHeading)elementType).getHeading();
			p.print("ARRAY " + heading + " {");
		} else
			p.print("ARRAY {");
		long count = 0;
		for (Value value: values) {
			if (count++ > 0)
				p.print(',');
			p.print("\n\t");
			value.toStream(generator, context, elementType, p, depth + 1);
		}
		p.print("\n}");		
	}
	
	/** Output this Value to a PrintStream. */
	public void toStream(Generator generator, Context context, Type type, PrintStream p, int depth) {
		if (values == null)
			toStreamFromRelation(generator, context, type, p, depth);
		else
			toStreamFromArray(generator, context, type, p, depth);
	}
		
	public int compareTo(Generator generator, Value v) {
		throw new ExceptionSemantic("ARRAY does not support comparison.");
	}

	public String toString() {
		return "[<Array>]";
	}

}
