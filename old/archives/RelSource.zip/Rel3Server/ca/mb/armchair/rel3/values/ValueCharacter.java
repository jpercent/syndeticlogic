package ca.mb.armchair.rel3.values;

import java.io.PrintStream;

import ca.mb.armchair.rel3.generator.Generator;
import ca.mb.armchair.rel3.types.Type;
import ca.mb.armchair.rel3.types.TypeAlpha;
import ca.mb.armchair.rel3.types.builtin.TypeCharacter;
import ca.mb.armchair.rel3.vm.Context;

public class ValueCharacter extends ValueAlpha {
	
	private static final long serialVersionUID = 0;

	private String internalValue;
	
	/** Return a String given a quote-delimited source string. */
	public static String stripDelimitedString(String b) {
		return b.substring(1, b.length() - 1);
	}
	
	/** Return a ValueCharacter given a quote-delimited source string. */
	public static Value stripDelimited(Generator generator, String b) {
		return new ValueCharacter(generator, stripDelimitedString(b));
	}
	
	public static ValueCharacter select(Generator generator, String x) {
		return (ValueCharacter)generator.selectValue(TypeCharacter.getInstance(), new ValueCharacter(generator, x));
	}
	
	private ValueCharacter(Generator generator, String b) {
		super(generator, TypeCharacter.getInstance(), new Value[1], 0);
		internalValue = b;
	}
 	
	public Value getComponentValue(Generator generator, int offsetInValue) {
		return select(generator, internalValue);
	}

	public void setComponentValue(int offsetInValue, Value value) {
		internalValue = value.stringValue();
	}
	
	public void toStream(Generator generator, Context context, Type contextualType, PrintStream p, int depth) {
		TypeAlpha type = (TypeAlpha) getType(generator, context.getVirtualMachine().getRelDatabase());
		setMST(generator.findMST(type, new ValueCharacter(generator, internalValue)));
		String typeSignature = getType(generator, generator.getDatabase()).getSignature(); 
		if (typeSignature.equals(TypeCharacter.Name))
			p.print((depth > 0) ? toParsableString(contextualType) : toString());
		else
			p.print(typeSignature + "(" + toParsableString(contextualType) + ")");
	}

	/** Convert this to a primitive boolean. */
	public boolean booleanValue() {
		return (internalValue.compareToIgnoreCase("true")==0) ? true : false;
	}
	
	/** Convert this to a primitive long. */
	public long longValue() {
		return (long)Double.parseDouble(internalValue);
	}
	
	/** Convert this to a primitive double. */
	public double doubleValue() {
		return Double.parseDouble(internalValue);
	}
	
	/** Convert this to a primitive String. */
	public String stringValue() {
		return internalValue;
	}

	public int compareTo(Generator generator, Value v) {
		return internalValue.compareTo(v.stringValue());
	}
	
	/** Add performs string concatenation. */
	public Value add(Generator generator, Value v) {
		return new ValueCharacter(generator, internalValue + v.stringValue());
	}
	
	public String toString() {
		return internalValue;
	}

	public String toParsableString(Type type) {
		return "\"" + StringUtils.quote(internalValue) + "\"";
	}

}
