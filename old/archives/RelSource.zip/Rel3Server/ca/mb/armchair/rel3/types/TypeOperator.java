package ca.mb.armchair.rel3.types;

import ca.mb.armchair.rel3.values.*;
import ca.mb.armchair.rel3.exceptions.ExceptionFatal;
import ca.mb.armchair.rel3.exceptions.ExceptionSemantic;
import ca.mb.armchair.rel3.generator.Generator;

public class TypeOperator extends TypeAbstract {

	private static TypeOperator instance = new TypeOperator();
	
	protected TypeOperator() {
	}
	
	public static TypeOperator getInstance() {
		return instance;
	}
	
	/** Obtain this type's signature. */
	public String getSignature() {
		return "OPERATOR";
	}
	
	/** Return true if source can be assigned to variables of this type. */
	public boolean canAccept(Type source) {
		return (source.getClass() == getClass());
	}
	
	/** Obtain a default value of this type. */
	public Value getDefaultValue(Generator generator) {
		throw new ExceptionFatal("Cannot generate a default value for an Operator type.");
	}

	protected Type canCompare(Type v) {
		throw new ExceptionSemantic("Cannot perform comparison on " + this);
	}

}
