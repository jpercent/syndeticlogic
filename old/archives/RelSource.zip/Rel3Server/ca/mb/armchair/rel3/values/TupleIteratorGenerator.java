package ca.mb.armchair.rel3.values;

import ca.mb.armchair.rel3.generator.Generator;

public interface TupleIteratorGenerator {
	public TupleIterator iterator(Generator generator);
}
