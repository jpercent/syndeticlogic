package ca.mb.armchair.rel3.storage;

import com.sleepycat.je.*;

public abstract class TransactionRunner {
	public abstract Object run(Transaction txn) throws Throwable;
	public Object execute(RelDatabase environment) throws Throwable {
		boolean ran = false;
		Object returnvalue = null;
		RelTransaction txn = environment.beginTransaction();
		try {
			returnvalue = run(txn.getTransaction());
			ran = true;
		} catch (Throwable t) {
			environment.rollbackTransaction(txn);
			throw t;
		}
		if (ran)
			environment.commitTransaction(txn);
		return returnvalue;
	}
}
