package ca.mb.armchair.rel3.values;

import java.util.TreeSet;
import java.util.Iterator;

import ca.mb.armchair.rel3.generator.Generator;

/** Lightweight literal relation. */
public class ValueRelationLiteral extends ValueRelation {

	private static final long serialVersionUID = 0;

	private TreeSet<ValueTuple> tuples;
	
	// TODO - modify ValueRelationLiteral to avoid out-of-memory on high-cardinality relations.
	public ValueRelationLiteral(Generator generator) {
		super(generator);
		tuples = new TreeSet<ValueTuple>(new ComparisonHandler());
	}
	
	/** Duplicates are silently ignored. */
	public void insert(ValueTuple tuple) {
		tuples.add(tuple);
	}
	
	public void remove(ValueTuple tuple) {
		tuples.remove(tuple);
	}
	
	@Override
	public TupleIterator newIterator(final Generator generator) {
		return new TupleIterator() {
			Iterator<ValueTuple> i = tuples.iterator();
			public boolean hasNext() {
				return i.hasNext();
			}
			public ValueTuple next() {
				ValueTuple tuple = i.next();
				tuple.loaded(generator);
				return tuple;
			}
			public void close() {
			}
		};
	}
	
	@Override
	public long getCardinality(Generator generator) {
		return tuples.size();
	}
		
	@Override
	public boolean contains(Generator generator, ValueTuple tuple) {
		return tuples.contains(tuple);
	}
	
}
