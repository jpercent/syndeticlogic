package ca.mb.armchair.rel3.values;
 
import java.io.PrintStream;
import java.io.Serializable;

import ca.mb.armchair.rel3.generator.Generator;
import ca.mb.armchair.rel3.types.*;
import ca.mb.armchair.rel3.vm.Context;

/** An abstract Value, that defines all possible operations on abstract ValueS.
 * 
 *  If an operation is not supported, throw SemanticException.
 */
public interface Value extends Serializable, Comparable<Value> {
	
	/** Invoked on retrieval from database */
	public void loaded(Generator generator);
	
	/** Obtain the type name of this Value. */
	public String getTypeName();
	
	/** Output this Value, interpreted as the given Type, to a PrintStream. */
	public void toStream(Generator generator, Context context, Type type, PrintStream p, int depth);
	
	/** Write as parsable string. */
	public String toParsableString(Type type);
	
	/** Write as final string. */
	public String toString(Type type);
	
	/** Compare this value and another. */
	public int compareTo(Generator generator, Value v);

	/** Check for equality. */
	public boolean equals(Object o);

	/** Obtain a serializable clone of this value.  Used to obtain serializable RVA values in TempStorageTuples,
	 but may be needed elsewhere??? */
	// TODO - explore eliminating this, if possible
	public Value getSerializableClone(Generator generator);
	
	/** Convert this to a primitive boolean. */
	public boolean booleanValue();
	
	/** Convert this to a primitive long. */
	public long longValue();
	
	/** Convert this to a primitive double. */
	public double doubleValue();

	/** Convert this to a primitive string. */
	public String stringValue();
}
