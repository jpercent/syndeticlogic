package ca.mb.armchair.rel3.values;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.NoSuchElementException;
import java.util.TreeSet;

import ca.mb.armchair.rel3.storage.RelDatabase;
import ca.mb.armchair.rel3.storage.TempStorageTuples;
import ca.mb.armchair.rel3.types.*;
import ca.mb.armchair.rel3.types.builtin.TypeInteger;
import ca.mb.armchair.rel3.vm.Context;
import ca.mb.armchair.rel3.exceptions.*;
import ca.mb.armchair.rel3.generator.Generator;
import ca.mb.armchair.rel3.generator.SelectOrder;

public abstract class ValueRelation extends ValueAbstract implements Projectable, TupleIteratorGenerator {
	
	public ValueRelation(Generator generator) {
		super(generator);
	}

	private static final long serialVersionUID = 0;
	
	/** Obtain a serializable clone of this value. */
	public Value getSerializableClone(Generator generator) {
		// TODO - fix this to use TempStorageTuples in an appropriate manner, i.e., one that doesn't invoke getSerializableClone()
		ValueRelationLiteral newRelation = new ValueRelationLiteral(generator);
		TupleIterator iterator = iterator(generator);
		while (iterator.hasNext())
			newRelation.insert((ValueTuple)iterator.next().getSerializableClone(generator));
		return newRelation;
	}

	public static ValueRelation getDum(Generator generator) {
		return new ValueRelation(generator) {
			private static final long serialVersionUID = 0;

			public TupleIterator newIterator(Generator generator) {
				return new TupleIterator() {
					public boolean hasNext() {
						return false;
					}

					public ValueTuple next() {
						throw new NoSuchElementException();
					}
					
					public void close() {}
				};
			}
		};
	}

	public static ValueRelation getDee(Generator generator) {
		return new ValueRelation(generator) {
			private static final long serialVersionUID = 0;

			public TupleIterator newIterator(final Generator generator) {
				return new TupleIterator() {
					public boolean available = true;

					public boolean hasNext() {
						return available;
					}

					public ValueTuple next() {
						if (available)
							try {
								return ValueTuple.getEmptyTuple(generator);
							} finally {
								available = false;
							}
						throw new NoSuchElementException();
					}
					
					public void close() {}
				};
			}
		};	
	}

	public ValueTuple getTuple(Generator generator) {
		TupleIterator iterator = iterator(generator);
		try {
			if (iterator.hasNext()) {
				ValueTuple tuple = iterator.next();
				if (!iterator.hasNext())
					return tuple;
			}
		} finally {
			iterator.close();
		}
		throw new ExceptionSemantic(
				"TUPLE FROM expects a relation with cardinality equal to one.");
	}

	public Value project(Generator generator, final AttributeMap map) {
		return new ValueRelation(generator) {
			private final static long serialVersionUID = 0;

			public TupleIterator newIterator(final Generator generator) {
				return new TupleIteratorUnique(new TupleIterator() {
					TupleIterator tuples = ValueRelation.this.iterator(generator);

					public boolean hasNext() {
						return tuples.hasNext();
					}

					public ValueTuple next() {
						return (ValueTuple)tuples.next().project(generator, map);
					}
					
					public void close() {
						tuples.close();
					}
				});
			}
		};
	}

	public ValueRelation union(Generator generator, final ValueRelation rightRelation) {
		return new ValueRelation(generator) {
			private final static long serialVersionUID = 0;

			public TupleIterator newIterator(final Generator generator) {
				return new TupleIteratorUnique(new TupleIterator() {
					TupleIterator left = ValueRelation.this.iterator(generator);
					TupleIterator right = rightRelation.iterator(generator);

					public boolean hasNext() {
						return (left.hasNext() || right.hasNext());
					}

					public ValueTuple next() {
						if (left.hasNext())
							return left.next();
						else if (right.hasNext())
							return right.next();
						throw new NoSuchElementException();
					}
					
					public void close() {
						left.close();
						right.close();
					}
				});
			}
		};
	}

	public ValueRelation dunion(Generator generator, final ValueRelation rightRelation) {
		return new ValueRelation(generator) {
			private final static long serialVersionUID = 0;

			public TupleIterator newIterator(final Generator generator) {
				return new TupleIteratorDisjoint(new TupleIterator() {
					TupleIterator left = ValueRelation.this.iterator(generator);
					TupleIterator right = rightRelation.iterator(generator);

					public boolean hasNext() {
						return (left.hasNext() || right.hasNext());
					}

					public ValueTuple next() {
						if (left.hasNext())
							return left.next();
						else if (right.hasNext())
							return right.next();
						throw new NoSuchElementException();
					}
					
					public void close() {
						left.close();
						right.close();
					}
				});
			}
		};
	}

	public ValueRelation intersect(Generator generator, final ValueRelation rightRelation) {
		return new ValueRelation(generator) {
			private final static long serialVersionUID = 0;

			public TupleIterator newIterator(final Generator generator) {
				return new TupleIterator() {
					TupleIterator left = ValueRelation.this.iterator(generator);
					ValueTuple current = null;

					public boolean hasNext() {
						if (current != null)
							return true;
						ValueTuple leftTuple;
						do {
							if (!left.hasNext())
								return false;
							leftTuple = left.next();
						} while (!rightRelation.contains(generator, leftTuple));
						current = leftTuple;
						return true;
					}

					public ValueTuple next() {
						if (hasNext())
							try {
								return current;
							} finally {
								current = null;
							}
						throw new NoSuchElementException();
					}
					
					public void close() {
						left.close();
					}
				};
			}
		};
	}

	public ValueRelation minus(Generator generator, final ValueRelation rightRelation) {
		return new ValueRelation(generator) {
			private final static long serialVersionUID = 0;

			public TupleIterator newIterator(final Generator generator) {
				return new TupleIterator() {
					TupleIterator left = ValueRelation.this.iterator(generator);
					ValueTuple current = null;

					public boolean hasNext() {
						if (current != null)
							return true;
						ValueTuple leftTuple;
						do {
							if (!left.hasNext())
								return false;
							leftTuple = left.next();
						} while (rightRelation.contains(generator, leftTuple));
						current = leftTuple;
						return true;
					}

					public ValueTuple next() {
						if (hasNext())
							try {
								return current;
							} finally {
								current = null;
							}
						throw new NoSuchElementException();
					}
					
					public void close() {
						left.close();
					}
				};
			}
		};
	}

	public ValueRelation product(Generator generator, final ValueRelation rightRelation) {
		return new ValueRelation(generator) {
			private final static long serialVersionUID = 0;

			public TupleIterator newIterator(final Generator generator) {
				return new TupleIterator() {
					TupleIterator left = ValueRelation.this.iterator(generator);
					TupleIterator right = null;
					ValueTuple current = null;
					ValueTuple leftTuple = null;

					public boolean hasNext() {
						if (current != null)
							return true;
						if (leftTuple != null) {
							if (!right.hasNext())
								leftTuple = null;
							else {
								current = leftTuple.joinDisjoint(generator, right.next());
								return true;
							}
						}
						if (leftTuple == null) {
							if (!left.hasNext())
								return false;
							leftTuple = left.next();
							if (right != null)
								right.close();
							right = rightRelation.iterator(generator);
							if (!right.hasNext())
								return false;
							current = leftTuple.joinDisjoint(generator, right.next());
						}
						return true;
					}

					public ValueTuple next() {
						if (hasNext())
							try {
								return current;
							} finally {
								current = null;
							}
						throw new NoSuchElementException();
					}
					
					public void close() {
						left.close();
						if (right != null)
							right.close();
					}
				};
			}
		};
	}
	
	public ValueRelation join(Generator generator, final RelDatabase database, final JoinMap map, final ValueRelation rightRelation) {
		return new ValueRelation(generator) {
			private final static long serialVersionUID = 0;
			
			public TupleIterator newIterator(final Generator generator) {
				return new TupleIterator() {
					boolean indexed = false;
					TempStorageTuples rightTuples = new TempStorageTuples(database);
					TupleIterator leftIterator = ValueRelation.this.iterator(generator);
					TupleIterator rightIterator;
					ValueTuple current = null;
					ValueTuple leftTuple = null;
					ValueTuple rightTuple = null;
					
					public boolean hasNextPair() {
						while (true) {
							if (rightIterator == null) {
								if (!leftIterator.hasNext())
									return false;
								leftTuple = leftIterator.next();
								if (indexed)
									rightIterator = rightTuples.keySearch(generator, map.getLeftTupleCommon(generator, leftTuple));
								else
									rightIterator = rightRelation.iterator(generator);
							}
							if (rightIterator.hasNext()) {
								rightTuple = rightIterator.next();
								if (indexed)
									return true;
								else {
									rightTuples.put(generator, map.getRightTupleCommon(generator, rightTuple), rightTuple);
									if (map.isJoinable(generator, leftTuple, rightTuple))
										return true;										
								}
							} else {
								indexed = true;
								rightIterator.close();
								rightIterator = null;
							}
						}
					}
					
					public boolean hasNext() {
						if (current != null)
							return true;
						if (!hasNextPair())
							return false;
						current = leftTuple.join(generator, map, rightTuple);
						return true;
					}

					public ValueTuple next() {
						if (hasNext())
							try {
								return current;
							} finally {
								current = null;
							}
						throw new NoSuchElementException();
					}

					public void close() {
						if (rightIterator != null)
							rightIterator.close();
						leftIterator.close();
						rightTuples.close();
					}
					
				};
			}
		};
	}

	/**
	 * Apply a native tuple operator to each tuple in a given relation, in order to
	 * generate a new relation.
	 * 
	 * @param map - a TupleMap
	 * @return - a ValueRelation
	 */
	public ValueRelation map(Generator generator, final TupleMap map) {
		return new ValueRelation(generator) {
			private final static long serialVersionUID = 0;

			public TupleIterator newIterator(final Generator generator) {
				return new TupleIterator() {
					TupleIterator iterator = ValueRelation.this.iterator(generator);

					public boolean hasNext() {
						return iterator.hasNext();
					}

					public ValueTuple next() {
						return map.map(iterator.next());
					}
					
					public void close() {
						iterator.close();
					}
				};
			}
		};
	}

	/**
	 * Ungroup a relation.
	 * 
	 * Note that the result includes ALL the original tuple attributes,
	 * including the specified RVA.
	 * 
	 * @param sourceMap -
	 *            mapping between original tuples and new tuples
	 * @param rvaMap -
	 *            mapping between original tuples' RVA and new tuples
	 * @param rvaIndex -
	 *            index of RVA in original tuple
	 * @param source -
	 *            ValueRelation containing at least one RVA, to which rvaIndex
	 *            points
	 * @return - ValueRelation
	 */
	public ValueRelation ungroup(Generator generator, final int resultDegree,
			final AttributeMap sourceMap, final AttributeMap rvaMap, final int rvaIndex) {
		return new ValueRelation(generator) {
			private final static long serialVersionUID = 0;

			public TupleIterator newIterator(final Generator generator) {
				return new TupleIterator() {
					ValueTuple current = null;
					TupleIterator outerIterator = ValueRelation.this.iterator(generator);
					TupleIterator innerIterator = null;
					ValueTuple outerTuple;
					boolean done = false;

					public boolean hasNext() {
						if (done)
							return false;
						if (current != null)
							return true;
						while (innerIterator == null || !innerIterator.hasNext()) {
							if (!outerIterator.hasNext()) {
								done = true;
								return false;
							}
							outerTuple = outerIterator.next();
							if (innerIterator != null)
								innerIterator.close();
							innerIterator = ((ValueRelation)outerTuple.getValues()[rvaIndex]).iterator(generator);
							if (innerIterator.hasNext())
								break;
							else
								continue;
						}
						Value[] buffer = new Value[resultDegree];
						current = new ValueTuple(generator, buffer);
						current.assign(generator, rvaMap, innerIterator.next());
						current.assign(generator, sourceMap, outerTuple);
						return true;
					}

					public ValueTuple next() {
						if (hasNext())
							try {
								return current;
							} finally {
								current = null;
							}
						throw new NoSuchElementException();
					}
					
					public void close() {
						outerIterator.close();
						if (innerIterator != null)
							innerIterator.close();
					}
				};
			}
		};
	}

	/**
	 * Apply a native boolean operator to each tuple in a given relation, in order to
	 * generate a new relation.
	 * 
	 * Tuples only appear in result if the operator returns true.
	 */
	public ValueRelation select(Generator generator, final TupleFilter filter) {
		return new ValueRelation(generator) {
			private final static long serialVersionUID = 0;

			public TupleIterator newIterator(final Generator generator) {
				return new TupleIterator() {
					TupleIterator iterator = ValueRelation.this.iterator(generator);
					ValueTuple current = null;

					public boolean hasNext() {
						if (current != null)
							return true;
						boolean testResult;
						ValueTuple next;
						do {
							if (!iterator.hasNext())
								return false;
							next = iterator.next();
							testResult = filter.filter(next);
						} while (!testResult);
						current = next;
						return true;
					}

					public ValueTuple next() {
						if (hasNext())
							try {
								return current;
							} finally {
								current = null;
							}
						throw new NoSuchElementException();
					}
					
					public void close() {
						iterator.close();
					}
				};
			}
		};
	}
	
	private static class Sorter implements Comparator<Value> {
		private Generator generator;
		private int map[];
		private SelectOrder.Order order[];
		public Sorter(Generator generator, OrderMap orderMap) {
			map = orderMap.getMap();
			order = orderMap.getOrder();
		}
		public int compare(Value t1, Value t2) {
			Value[] v1 = ((ValueTuple)t1).getValues();
			Value[] v2 = ((ValueTuple)t2).getValues();
			for (int i=0; i<map.length; i++) {
				int attributeIndex = map[i];
				int c = v1[attributeIndex].compareTo(generator, v2[attributeIndex]);
				if (c != 0)
					return (order[i] == SelectOrder.Order.ASC) ? c : -c;
			}
			return 0;
		}
	}
	
	/** Return a new, possibly-sorted ValueArray */
	public ValueArray sort(Generator generator, OrderMap map) {
		if (map.getMap().length == 0)
			return new ValueArray(generator, this);
		else {
			// TODO - fix so that high-cardinality relations don't run out of RAM
			final ArrayList<ValueTuple> array = new ArrayList<ValueTuple>();
	    	(new TupleIteration(iterator(generator)) {
	    		public void process(ValueTuple tuple) {
	    			array.add(tuple);		
	    		}
	    	}).run();
			Collections.sort(array, new Sorter(generator, map));
			return new ValueArray(generator, array);
		}
	}
	
	public abstract TupleIterator newIterator(Generator generator);

	public final TupleIterator iterator(Generator generator) {
		return newIterator(generator);
	}
	
	// TODO - replace this with something that won't out-of-memory on high-cardinality relations
	private TreeSet<ValueTuple> cache = null;
		
	private void buildCache(Generator generator) {
		cache = new TreeSet<ValueTuple>(new ComparisonHandler());
		(new TupleIteration(iterator(generator)) {
			public void process(ValueTuple tuple) {
				cache.add(tuple);
			}
		}).run();
	}

	public boolean contains(Generator generator, ValueTuple findMe) {
		if (cache == null)
			buildCache(generator);
		return cache.contains(findMe);
	}

	public String getTypeName() {
		return "RELATION";
	}

	/** Output this Value to a PrintStream. */
	public void toStream(Generator generator, Context context, Type type, PrintStream p, int depth) {
		Heading heading = ((TypeRelation)type).getHeading();
		TypeTuple tupleType = new TypeTuple(heading);
		if (depth == 0)
			p.print("RELATION " + heading + " {");
		else
			p.print("RELATION {");
		long count = 0;
		TupleIterator iterator = iterator(generator);
		try {
			while (iterator.hasNext()) {
				ValueTuple tuple = iterator.next();
				if (count++ > 0)
					p.print(',');
				p.print("\n\t");
				tuple.toStream(generator, context, tupleType, p, depth + 1);
			}
		} finally {
			iterator.close();
		}
		p.print("\n}");
	}

	// For debugging purposes
	public String toString(Generator generator) {
		String s = "";
		s += "RELATION {";
		long count = 0;
		TupleIterator iterator = iterator(generator);
		try {
			while (iterator.hasNext()) {
				ValueTuple tuple = iterator.next();
				if (count++ > 0)
					s += ',';
				s += "\n\t";
				s += tuple.toString();
			}
		} finally {
			iterator.close();
		}
		s += "\n}";
		return s;
	}
	
	public long getCardinality(Generator generator) {
		if (cache == null)
			buildCache(generator);
		return cache.size();
	}

	private final boolean isTestedSubsetOf(Generator generator, ValueRelation rightSide) {
		TupleIterator iterator = iterator(generator);
		try {
			while (iterator.hasNext()) {
				ValueTuple tuple = iterator.next();
				if (!rightSide.contains(generator, tuple))
					return false;
			}
		} finally {
			iterator.close();
		}
		return true;
	}

	/** Test for <=, i.e., left is subset of right */
	public boolean isSubsetOf(Generator generator, ValueRelation rightSide) {
		if (getCardinality(generator) > rightSide.getCardinality(generator))
			return false;
		else
			return isTestedSubsetOf(generator, rightSide);
	}

	/** Test for >=, i.e., left is superset of right */
	public boolean isSupersetOf(Generator generator, ValueRelation v) {
		return v.isSubsetOf(generator, this);
	}

	/** Test for >, i.e. left is proper superset of right */
	public boolean isProperSupersetOf(Generator generator, ValueRelation v) {
		return v.isProperSubsetOf(generator, this);
	}

	/** Test for <, i.e. left is proper subset of right */
	public boolean isProperSubsetOf(Generator generator, ValueRelation v) {
		return isSubsetOf(generator, v) && neq(generator, v);
	}
	
	public int compareTo(Generator generator, Value v) {
		// TODO - this can surely be optimised
		if (eq(generator, (ValueRelation)v))
			return 0;
		if (isSubsetOf(generator, (ValueRelation)v))
			return -1;
		else
			return 1;		
	}
	
	/** Test this relation and another for equality. */
	public boolean eq(Generator generator, ValueRelation rightSide) {
		if (getCardinality(generator) != rightSide.getCardinality(generator))
			return false;
		else
			return isTestedSubsetOf(generator, rightSide);
	}

	/** Test this relation and another for non-equality. */
	public boolean neq(Generator generator, ValueRelation v) {
		return !eq(generator, v);
	}

	private static ValueRelation tclose(Generator generator, JoinMap joinMap, AttributeMap projectMap, ValueRelation xy) {
		ValueRelation ttt = xy.union(generator, (ValueRelation)xy.join(generator, generator.getDatabase(), joinMap, xy).project(generator, projectMap));
		return (ttt.eq(generator, xy)) ? ttt : tclose(generator, joinMap, projectMap, ttt);
	}
	
	public Value tclose(Generator generator) {
		Type attributeType = TypeInteger.getInstance(); // type is irrelevant here; any will do
		Heading left = new Heading();
		left.add("X", attributeType);
		left.add("LINK", attributeType);	
		Heading right = new Heading();
		right.add("LINK", attributeType);
		right.add("Y", attributeType);
		Heading joinTarget = new Heading();
		joinTarget.add("X", attributeType);
		joinTarget.add("LINK", attributeType);
		joinTarget.add("Y", attributeType);
		Heading projectTarget = new Heading();
		projectTarget.add("X", attributeType);
		projectTarget.add("Y", attributeType);
		JoinMap joinMap = new JoinMap(joinTarget, left, right);
		AttributeMap projectMap = new AttributeMap(projectTarget, joinTarget);
		return tclose(generator, joinMap, projectMap, this);
	}

	public ValueBoolean is_empty(Generator generator) {
		TupleIterator iterator = iterator(generator);
		try {
			return (ValueBoolean)ValueBoolean.select(generator, !iterator.hasNext());
		} finally {
			iterator.close();
		}
	}
	
	/** Aggregate operator */
	public Value sumInteger(final Generator generator, final int attributeIndex) {
		TupleFold folder = new TupleFold(iterator(generator), attributeIndex) {
			public Value getIdentity() {
				return ValueInteger.select(generator, 0);
			}
			public Value fold(Value left, Value right) {
				return ValueInteger.select(generator, left.longValue() + right.longValue());
			}
		};
		folder.run();
		return folder.getResult();
	}

	/** Aggregate operator */
	public Value sumRational(final Generator generator, final int attributeIndex) {
		TupleFold folder = new TupleFold(iterator(generator), attributeIndex) {
			public Value getIdentity() {
				return ValueRational.select(generator, 0);
			}
			public Value fold(Value left, Value right) {
				return ValueRational.select(generator, left.doubleValue() + right.doubleValue());
			}
		};
		folder.run();
		return folder.getResult();
	}

	/** Aggregate operator */
	public ValueRational avgInteger(final Generator generator, int attributeIndex) {
		TupleFold folder = new TupleFold(iterator(generator), attributeIndex) {
			public Value getIdentity() {
				return ValueInteger.select(generator, 0);
			}
			public Value fold(Value left, Value right) {
				return ValueInteger.select(generator, left.longValue() + right.longValue());
			}
		};
		folder.run();
		Value sum = folder.getResult();
		if (folder.getCount() == 0)
			throw new ExceptionSemantic("Result of AVG on no values is undefined.");
		else
			return (ValueRational)ValueRational.select(generator, sum.doubleValue() / (double)folder.getCount());
	}

	/** Aggregate operator */
	public ValueRational avgRational(final Generator generator, int attributeIndex) {
		TupleFold folder = new TupleFold(iterator(generator), attributeIndex) {
			public Value getIdentity() {
				return ValueRational.select(generator, 0);
			}
			public Value fold(Value left, Value right) {
				return ValueRational.select(generator, left.doubleValue() + right.doubleValue());
			}
		};
		folder.run();
		Value sum = folder.getResult();
		if (folder.getCount() == 0)
			throw new ExceptionSemantic("Result of AVG on no values is undefined.");
		else
			return (ValueRational)ValueRational.select(generator, sum.doubleValue() / (double)folder.getCount());
	}

	/** Aggregate operator */
	public Value max(final Generator generator, int attributeIndex) {
		TupleFold folder = new TupleFoldFirstIsIdentity("Result of MAX on no values is undefined.", iterator(generator), attributeIndex) {
			public Value fold(Value left, Value right) {
				if (left.compareTo(generator, right) > 0)
					return left;
				else
					return right;
			}
		};
		folder.run();
		return folder.getResult();
	}

	/** Aggregate operator */
	public Value min(final Generator generator, int attributeIndex) {
		TupleFold folder = new TupleFoldFirstIsIdentity("Result of MIN on no values is undefined.", iterator(generator), attributeIndex) {
			public Value fold(Value left, Value right) {
				if (left.compareTo(generator, right) < 0)
					return left;
				else
					return right;
			}
		};
		folder.run();
		return folder.getResult();
	}

	/** Aggregate operator */
	public ValueBoolean and(final Generator generator, int attributeIndex) {
		TupleFold folder = new TupleFold(iterator(generator), attributeIndex) {
			public Value getIdentity() {
				return ValueBoolean.select(generator, true);
			}
			public Value fold(Value left, Value right) {
				return ValueBoolean.select(generator, left.booleanValue() & right.booleanValue());
			}
		};
		folder.run();
		return (ValueBoolean)folder.getResult();
	}

	/** Aggregate operator */
	public ValueBoolean or(final Generator generator, int attributeIndex) {
		TupleFold folder = new TupleFold(iterator(generator), attributeIndex) {
			public Value getIdentity() {
				return ValueBoolean.select(generator, false);
			}
			public Value fold(Value left, Value right) {
				return ValueBoolean.select(generator, left.booleanValue() | right.booleanValue());
			}
		};
		folder.run();
		return (ValueBoolean)folder.getResult();
	}

	/** Aggregate operator */
	public ValueBoolean xor(final Generator generator, int attributeIndex) {
		TupleFold folder = new TupleFold(iterator(generator), attributeIndex) {
			public Value getIdentity() {
				return ValueBoolean.select(generator, false);
			}
			public Value fold(Value left, Value right) {
				return ValueBoolean.select(generator, left.booleanValue() ^ right.booleanValue());
			}
		};
		folder.run();
		return (ValueBoolean)folder.getResult();
	}

	/** Aggregate operator */
	public ValueRelation union(final Generator generator, int attributeIndex) {
		TupleFold folder = new TupleFoldFirstIsIdentity("Result of UNION on no values is undefined.", iterator(generator), attributeIndex) {
			public Value fold(Value left, Value right) {
				return ((ValueRelation)left).union(generator, (ValueRelation)right);
			}
		};
		folder.run();
		return (ValueRelation)folder.getResult();
	}

	/** Aggregate operator */
	public ValueRelation d_union(final Generator generator, int attributeIndex) {
		TupleFold folder = new TupleFoldFirstIsIdentity("Result of D_UNION on no values is undefined.", iterator(generator), attributeIndex) {
			public Value fold(Value left, Value right) {
				return ((ValueRelation)left).dunion(generator, (ValueRelation)right);
			}
		};
		folder.run();
		return (ValueRelation)folder.getResult();
	}

	/** Aggregate operator */
	public ValueRelation intersect(final Generator generator, int attributeIndex) {
		TupleFold folder = new TupleFoldFirstIsIdentity("Result of INTERSECT on no values is undefined.", iterator(generator), attributeIndex) {
			public Value fold(Value left, Value right) {
				return ((ValueRelation)left).intersect(generator, (ValueRelation)right);
			}
		};
		folder.run();
		return (ValueRelation)folder.getResult();
	}

	/** Aggregate operator */
	public ValueBoolean exactly(Generator generator, long nCount, int attributeIndex) {
		long trueCount = 0;
		TupleIterator iterator = iterator(generator);
		try {
			while (iterator.hasNext()) {
				ValueTuple t = iterator.next();
				trueCount += ((((ValueBoolean)t.getValues()[attributeIndex]).booleanValue()) ? 1 : 0);
			}
		} finally {
			iterator.close();
		}
		return (ValueBoolean)ValueBoolean.select(generator, trueCount == nCount);
	}
}
