#!/usr/bin/env python

class propositional_automaton_alphabet:
    def __init__(self, propositions):
        self.propositions = propositions
        self.valuations = self.__compute_valuations__(self.propositions.__len__())
        self.propositional_enumeration = \
            self.__propositional_enumeration_map__(self.propositions)
        
        print self.propositional_enumeration, ':'
        print '-'*80
        
        self.alphabet_map = self.__compute_alphabet_map__(self.valuations)
        print self.alphabet_map
        
    def __propositional_enumeration_map__(self, propositions):
        map = {}
        position = 0
        for i in propositions:
            map[i] = position
            position += 1
        return map
    def __compute_alphabet_map__(self, propositional_valuations):
        count = 0
        alpha_map = {}
        for i in propositional_valuations:
            #print i
            alpha_map[i] = count
            count += 1
        return alpha_map
    def __compute_valuations__(self, count):
        if count == 1:
            return ((False,),(True,))
        else:
            next_valuation = ()
            pvaluation = self.__compute_valuations__((count - 1))
            for i in pvaluation:
                t = i + (False,)
                t1 = i + (True,)
                next_valuation += (t,)
                next_valuation += (t1,)
            return next_valuation 
    def get_propositions(self):
        return self.propositions
    def get_propositional_map(self):
        return self.propositional_enumeration
    def get_alphabet_map(self):
        return self.alphabet_map
    
class propositional_automaton_symbol:
    def __init__(self, propositional_map, alphabet_map):
        self.propositional_map = propositional_map
        self.alpha_map = alphabet_map
        self.propositions = []
    def add_prop(self, proposition):
        assert proposition != None
        self.propositions.append(proposition)
    def get_propositions(self, propositions):
            return self.propositions
    def get_symbol(self):
        valuation = [False, False, False]
        print 'props: ', 
        for i in self.propositions:
            valuation[self.propositional_map[i]] = True
        return self.alpha_map[tuple(valuation)]
    
if __name__ == '__main__':
    print '-'*80
    props = ['p', 'q', 'r']
    p = propositional_automaton_alphabet(props)
    sym = propositional_automaton_symbol(p.get_propositional_map(),
                                         p.get_alphabet_map())
    print '-'*80
    sym.add_prop('p')
    print 'symbol: ', sym.get_symbol()
    sym.add_prop('q')
    print 'symbol: ', sym.get_symbol()

    #propositional_symbols(5)
    
    