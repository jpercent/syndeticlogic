#!/usr/bin/env python

import base_parser
import formulae

class default_syntax_tree:
    def __init__(self):
        self.formula_list = []
    def get_tree(self):
        return self.formula_list
    def binary(self, lhs, operator, rhs, type):
        self.formula_list.append((type,lhs, operator, rhs))
        return lhs + operator + rhs
    def unary(self, operator, operand, type):
        self.formula_list.append((type, operator, operand))
        return operator + operand
    def prop(self, element):
        self.formula_list.append((formulae.PROPOSITION, element))
        return element
    def constant(self, element, value):
        self.formula_list.append((formulae.CONSTANT, element, value))
        return element
    def subformula(self, lparen, formula, rparen):
        self.formula_list.append((formulae.SUBFORMULA, lparen, formula, rparen))
        return (lparen + formula + rparen)

class parser(base_parser.Parser):
    tokens = ('EVENTUALLY','GLOBALLY', 'NEXT', 'UNTIL', 'AND','OR','LNOT','PROP',
              'LPAREN','RPAREN', 'CONSTANT_TRUE', 'CONSTANT_FALSE', 'RELEASES',
              'IMPLIES')
    t_EVENTUALLY = r'\{F\}'
    t_GLOBALLY = r'\{G\}'
    t_NEXT = r'\{X\}'
    t_LNOT = r'\~'
    t_AND = r'\&'
    t_OR = r'\|'
    t_UNTIL = r'\{U\}'
    t_RELEASES = r'\{R\}'
    t_LPAREN = r'\('
    t_RPAREN = r'\)'
    t_IMPLIES = r'\-\>'
    t_PROP = r'[a-zA-Z_][a-zA-Z_]*'
    t_CONSTANT_TRUE = r'-T-'
    t_CONSTANT_FALSE = r'-F-'
    t_ignore = " \t"
    def t_newline(self, t):
        r'\n+'
        t.lexer.lineno += t.value.count("\n")
    def t_error(self, t):
        print "Illegal character '%s'" % t.value[0]
        t.lexer.skip(1)
    
    precedence = (
        ('left', 'AND', 'OR', 'UNTIL', 'RELEASES', 'IMPLIES'),
        ('right', 'EVENTUALLY', 'GLOBALLY', 'NEXT', 'LNOT')
    )
    def p_formula_binary(self, p):
        '''formula : formula AND formula
                   | formula OR formula
                   | formula UNTIL formula
                   | formula IMPLIES formula
                   | formula RELEASES formula'''
        if p[2] == '&':
            type = formulae.CONJUNCTION
        elif p[2] == '|':
            type = formulae.DISJUNCTION
        elif p[2] == '{U}':
            type = formulae.UNTIL
        elif p[2] == '{R}':
            type = formulae.RELEASES
        elif p[2] == '->':
            type = formulae.IMPLIES
        p[0] = self.syntax_tree.binary(p[1], p[2],p[3], type)
    def p_formula_unary(self, p):
        '''formula : EVENTUALLY formula
                   | GLOBALLY formula
                   | LNOT formula
                   | NEXT formula'''
        if p[1] == '{F}':
            type = formulae.EVENTUALLY
        elif p[1] == '{G}':
            type = formulae.GLOBALLY
        elif p[1] == '{X}':
            type = formulae.NEXT
        elif p[1] == '~':
            type = formulae.NEGATION
        p[0] = self.syntax_tree.unary(p[1], p[2], type)
    def p_formula_constant(self, p):
        '''formula : CONSTANT_FALSE
                    | CONSTANT_TRUE'''
        const = None
        if p[1] == '-T-':
            const = self.syntax_tree.constant(p[1], True)
        elif p[1] == '-F-':
            const = self.syntax_tree.constant(p[1], False)
        assert const != None
        p[0] = const
    def p_formula_prop(self, p):
        '''formula : PROP'''
        p[0] = self.syntax_tree.prop(p[1])
    def p_formula_subformula(self, p):
        '''formula : LPAREN formula RPAREN'''
        p[0] = self.syntax_tree.subformula(p[1], p[2],p[3])
    def p_error(self, p):
        if p:
            print "Syntax error at '%s'" % p.value
        else:
            print "Syntax error at EOF"
    def parse(self, word, ast):
        assert ast != None
        assert word != None
        self.syntax_tree = ast
        self.run_parser(word)
