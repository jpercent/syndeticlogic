#!/usr/bin/env python

import unittest
import formulae
from formulae_defines import *

class ast_test(unittest.TestCase):
    def setUp(self):
        self.ast = formulae.formula_ast()
    def test_binary(self):
        binary = self.ast.binary(formulae.constant('l33t', True), '{U}',
                               formulae.constant('1337', True), UNTIL)
        self.assertTrue(isinstance(binary, formulae.binary))
        self.assertEquals('l33t{U}1337', binary.get_formula())
        self.assertEquals(UNTIL, binary.get_type())
        self.assertEquals(binary, self.ast.root)
        
        binary = self.ast.binary(formulae.constant('l33t', True), '->',
                               formulae.constant('1337', True), IMPLIES)
        self.assertTrue(isinstance(binary, formulae.binary))
        self.assertEquals('~l33t|1337', binary.get_formula())
        self.assertEquals(DISJUNCTION, binary.get_type())
        self.assertEquals(binary, self.ast.root)
    def test_unary(self):
        unary = self.ast.unary('{X}', formulae.constant('1337', True),
                             NEXT)
        self.assertTrue(isinstance(unary, formulae.unary))
        self.assertEquals('{X}1337', unary.get_formula())
        self.assertEquals(NEXT, unary.get_type())
        self.assertEquals(unary, self.ast.root)
        
        unary = self.ast.unary('{F}', formulae.constant('1337', True),
                             EVENTUALLY)
        self.assertTrue(isinstance(unary, formulae.binary))
        self.assertEquals(UNTIL, unary.get_type())
        self.assertEquals('-T-{U}1337', unary.get_formula())
        self.assertEquals(unary, self.ast.root)
        
        unary = self.ast.unary('{G}', formulae.constant('1337', True),
                              EVENTUALLY)
        self.assertTrue(isinstance(unary, formulae.binary))
        self.assertEquals(RELEASES, unary.get_type())
        self.assertEquals('-F-{R}1337', unary.get_formula())
        self.assertEquals(unary, self.ast.root)
        
        unary = self.ast.unary('~', formulae.constant('l4m3z', True),
                              NEGATION)
        self.assertTrue(isinstance(unary, formulae.unary))
        self.assertEquals(NEGATION, unary.get_type())
        self.assertEquals('~l4m3z', unary.get_formula())
        self.assertEquals(unary, self.ast.root)
      
    def test_subformula(self):
        sub = self.ast.subformula('x', formulae.constant('1337', True),
                                  'y')
        self.assertTrue(isinstance(sub, formulae.subformula))
        self.assertEquals('(1337)', sub.get_formula())
        self.assertEquals(sub, self.ast.root)
    def test_prop(self):
        prop = self.ast.prop('l33t')
        self.assertTrue(isinstance(prop, formulae.proposition))
        self.assertEquals('l33t', prop.get_formula())
        self.assertEquals(False, prop.get_value())
        self.assertEquals(prop, self.ast.root)
    def test_constant(self):
        const = self.ast.constant('31337', True)
        self.assertTrue(isinstance(const, formulae.constant))
        self.assertEquals('31337', const.get_formula())
        self.assertEquals(True, const.get_value())
        self.assertEquals(const, self.ast.root)
    
class mock_formula:
    def __init__(self, name, children, type):
        self.name = name
        self.accept_call_count = 0
        self.children = children
        self.type = type
    def accept(self, visitor):
        self.accept_call_count += 1
    def get_children(self):
        return self.children
    def get_type(self):
        return self.type
    
class subformulae_visitor_test(unittest.TestCase):
    def test(self):
        mock_decl = mock_formula('decl', None, 0)
        mock_unary = mock_formula('unary', [mock_decl], NEXT)
        mock_subformula = mock_formula('subformula', [mock_unary], SUBFORMULA)
        mock_binary = mock_formula('binary', [mock_unary, mock_subformula],
                                   CONJUNCTION)
        
        visitor = formulae.subformulae_visitor()
        decl = 'j4m35%-r0x0rz'
        visitor.visit_decl(decl)
        self.assertEqual(visitor.subformulae.__len__(), 1)
        self.assertEqual(visitor.subformulae[0], decl) 
      
        visitor.visit_unary(mock_unary)
        self.assertEqual(visitor.subformulae.__len__(), 2)
        self.assertEqual(visitor.subformulae[0], decl)
        self.assertEqual(visitor.subformulae[1], mock_unary)
        self.assertEquals(mock_decl.accept_call_count, 1)
        
        visitor.visit_subformula(mock_subformula)
        self.assertEqual(visitor.subformulae.__len__(), 2)
        self.assertEqual(visitor.subformulae[0], decl)
        self.assertEqual(visitor.subformulae[1], mock_unary)
        self.assertEquals(mock_unary.accept_call_count, 1)
        
        visitor.visit_binary(mock_binary)
        self.assertEqual(visitor.subformulae.__len__(), 3)
        self.assertEqual(visitor.subformulae[0], decl)
        self.assertEqual(visitor.subformulae[1], mock_unary)
        self.assertEqual(visitor.subformulae[2], mock_binary)
        self.assertEquals(mock_unary.accept_call_count, 2)
        self.assertEquals(mock_subformula.accept_call_count, 1)
    
        visitor = formulae.subformulae_visitor()
        new_mock_decl = mock_formula('decl', None, 0)
        negation_mock_unary = mock_formula('unary', [new_mock_decl], NEGATION)
        
        visitor.visit_unary(mock_unary)
        self.assertEqual(visitor.subformulae.__len__(), 1)
        self.assertEqual(visitor.subformulae[0], mock_unary)
        self.assertEquals(new_mock_decl.accept_call_count, 0)


class factory_test(unittest.TestCase):
    def test(self):
        factory = formulae.formula_factory()
        formula = factory.create_formula('-T-{U}q')
        self.assertTrue(isinstance(formula, formulae.binary))
        self.assertEquals('-T-{U}q', formula.get_formula())
        self.assertEquals(UNTIL, formula.get_type())
        
        print 'factory test '
        formu= factory.create_formula('~(p&q)')
        print formu.get_formula()
        formula = factory.create_formula('~((p{U}q)&(p|q))')
        print formula.get_formula()
        return

class mock_visitor:
    def __init__(self):
        self.decl = 0
        self.un = 0
        self.bin = 0
        self.sub = 0
    def visit_decl(self, decl):
        assert isinstance(decl, formulae.constant) or isinstance(
            decl,formulae.proposition)
        self.decl += 1
    def visit_unary(self, unary):
        assert isinstance(unary, formulae.unary)
        self.un += 1
    def visit_subformula(self, sub):
        assert isinstance(sub, formulae.subformula)
        self.sub += 1
    def visit_binary(self, binary):
        assert isinstance(binary, formulae.binary)
        self.bin += 1

class formulae_test(unittest.TestCase):
    def setUp(self):
        self.mockv = mock_visitor()
    def test_formula(self):
        self.name = 'j4m35% i5 4 r0x0r 574r'
        formula = formulae.formula(self.name, UNTIL, COMPOSITE)
        self.assertEqual(self.name, formula.get_formula())
        self.assertEqual(COMPOSITE, formula.get_composition())
        self.assertEqual(UNTIL,formula.get_type())
        formula.set_type(RELEASES)
        self.assertEqual(RELEASES, formula.get_type())
        self.assertEqual([], formula.get_children())
        self.assertEqual(None, formula.get_subformulae())
        self.assertEqual(None, formula.get_subformulae_powerset())
        self.assertEqual(None, formula.accept(self.mockv))
        self.assertTrue(self.mockv.decl == 0 and self.mockv.un == 0
                        and self.mockv.bin == 0 and self.mockv.sub == 0)
    def test_constant(self):
        const = formulae.constant('e133t', True)
        self.assertEqual('e133t', const.get_formula())
        self.assertEqual(PRIME, const.get_composition())
        self.assertEqual(CONSTANT,const.get_type())
        self.assertEqual([], const.get_children())
        self.assertEqual((const,), const.get_subformulae())
        print const.get_subformulae_powerset()
        self.assertEqual(((),(const,)), const.get_subformulae_powerset())
        self.assertEqual(None, const.accept(self.mockv))
        self.assertTrue(self.mockv.decl == 1 and self.mockv.un == 0
                        and self.mockv.bin == 0 and self.mockv.sub == 0)
        self.assertEqual(True, const.get_value())
        unary_negation = const.negate()
        # whaa??
        self.assertEqual('~e133t', unary_negation.get_formula())
        self.assertEqual(NEGATION, unary_negation.get_type())
        self.assertTrue(isinstance(unary_negation, formulae.unary))
    def check_tuple_contents_equal(self, actual, expected):
        expected_list = list(expected)
        actual_list = list(actual)
        self.assertEqual(actual.__len__(), expected.__len__())
        import copy
        # XXX this is broken.. for i in copy(expected_list:
        for i in expected_list:
            found = False
            for j in actual_list:
                if i == j:
                    expected_list.remove(i)
                    actual_list.remove(j)
                    found = True
            if found == False:
                print 'asserting tuples do not match: ', actual, ':', expected
                self.assertFalse('tuples not equal')
                
        self.assertEqual(expected_list.__len__(), actual_list.__len__())
    
    def test_prop(self):
        prop = formulae.proposition('p', False)
        self.assertEqual(PRIME, prop.get_composition())
        self.assertEqual(PROPOSITION, prop.get_type())
        self.assertEqual([], prop.get_children())
        self.assertEqual((prop,), prop.get_subformulae())
        self.assertEqual(((),(prop,)), prop.get_subformulae_powerset())
        self.assertTrue(self.mockv.decl == 0 and self.mockv.un == 0
                        and self.mockv.bin == 0 and self.mockv.sub == 0)
        self.assertEqual(None, prop.accept(self.mockv))
        self.assertTrue(self.mockv.decl == 1 and self.mockv.un == 0
                        and self.mockv.bin == 0 and self.mockv.sub == 0)
        self.assertEqual(False, prop.get_value())
        unary_negation = prop.negate()
        # whaa??
        self.assertEqual('~p', unary_negation.get_formula())
        self.assertEqual(NEGATION, unary_negation.get_type())
        self.assertTrue(isinstance(unary_negation, formulae.unary))
    def test_unary(self):
        prop = formulae.proposition('p', False)
        negation = formulae.unary('~', prop, NEGATION)
        self.assertEqual(COMPOSITE, negation.get_composition())
        self.assertEqual(NEGATION, negation.get_type())
        self.assertEqual([prop,], negation.get_children())
        self.check_tuple_contents_equal(((), (negation,)),
            negation.get_subformulae_powerset())
        self.assertTrue(self.mockv.decl == 0 and self.mockv.un == 0
                        and self.mockv.bin == 0 and self.mockv.sub == 0)
        self.assertEqual(None, negation.accept(self.mockv))
        self.assertTrue(self.mockv.decl == 0 and self.mockv.un == 1
                        and self.mockv.bin == 0 and self.mockv.sub == 0)
        
        unary_negation = negation.negate()
        # whaa??
        self.assertEqual('p', unary_negation.get_formula())
        self.assertEqual(PROPOSITION, unary_negation.get_type())
        self.assertTrue(isinstance(unary_negation, formulae.proposition))
    def test_binary(self):
        prop_p = formulae.proposition('p', False)
        not_p = formulae.unary('~', prop_p, NEGATION)
        prop_q = formulae.proposition('q', True)
        binary = formulae.binary(not_p, '&', prop_q, CONJUNCTION)
        #binary = formulae.binary(prop_p, '&', prop_q, CONJUNCTION)
        
    
    
        print ' here  -----------------------------\n\n'
        print binary.get_formula()
        for i in binary.get_subformulae_powerset():
            print i
        print ' ------------------------- here \n\n'
        
        binary = formulae.binary(not_p, '|', prop_p, DISJUNCTION)
        print binary.get_formula()
        for i in binary.get_subformulae_powerset():
            print i
        print ' ------------------------- here \n\n'
            
        #print binary.subformulae
    def test_subformula(self):
        pass
    def test_satisfiable(self):
        print ' starting.. sat test... \n\n\n'
        prop = formulae.proposition('p', True)
        #
        factory = formulae.formula_factory()
        negation = factory.create_formula('~p')
        print negation.get_formula(), ' SAT: ', negation.satisfiable()
        
        negation = factory.create_formula('p')
        print negation.get_formula(), ' SAT: ', negation.satisfiable()
        
        
        #
        #until = factory.create_formula('p{U}q')
        #print  until.get_formula(), ' SAT: ', until.satisfiable()
        #
        #until = factory.create_formula('p&~p')
        #print  until.get_formula(), ' SAT: ',until.satisfiable()
        #
        #until = factory.create_formula('p&~p')
        #print  until.get_formula(), ' SAT: ',until.satisfiable()
        #
        #until = factory.create_formula('p|~p')
        #print  until.get_formula(), ' SAT: ',until.satisfiable()
        #
        #until = factory.create_formula('~(-F-{R}-T-)')
        #print until.get_formula(), ' SAT: ', until.satisfiable()
        #
        #until = factory.create_formula('~{X}(p|~p)')
        #print until.get_formula(), ' SAT: ', until.satisfiable()
        
        
        
        


















###############################################################################################################
#    def parser_test(self, phi, hand_made_formula):
#        factory = formulae.formula_factory()
#        subject = factory.create_formula(phi)
#        print subject.get_formula()
#        return
#        self.assertEqual(hand_made_formula.get_formula(), subject.get_formula())
#        for i in subject.get_closure():
#            print i.get_formula()
#        phi_closure = list(hand_made_formula.get_closure())
#        subject_closure_list = list(subject.get_closure())
#        self.assertEquals(phi_closure.__len__(), subject.get_closure().__len__())
#        for i in phi_closure:
#            found = False
#            for j in subject_closure_list:
#                if j.get_formula() == i.get_formula():
#                    subject_closure_list.remove(j)
#                    found = True
#                    break
#            self.assertTrue(found)
#    def test(self):
#        #const_true = ltl.constant('-T-', 1)
#        #const_false = ltl.constant('-F-', 0)
#        prop_p = formulae.proposition('p')
#        prop_q = formulae.proposition('q')
#
#        #fconst_true = ltl.formula(const_true, (fconst_true,), (fconst_true,))
#        #fconst_false = ltl.formula(const_false, (fconst_false,), (fconst_false,))
#        #fprop_p = formulae.formula(prop_p, (prop_p,), (prop_p,))
#        self.parser_test('~p|q&~(p|q)', None)
#        
#        #self.parser_test('-T-', fconst_true)
#        #self.parser_test('-F-', fconst_false)
#        
#        
#        #neg_p = ltl.unary('~', fprop_p, ltl.NEGATION)
#        #fneg_p = ltl.formula(neg_p, (fprop_p, fneg_p), (fprop_p, fneg_p, (fprop_p, fneg_p)))
#        #self.parser_test('~p', fneg_p)
#        
#        #eventually_p = ltl.unary('{F}', prop_p, ltl.EVENTUALLY)
#        #feventually_p = ltl.formula(eventually_p, (prop_p, eventually_p), 
#        
#        #self.parser_test('{F}p', ('p', '{F}p'))
#        #self.parser_test('{G}p', ('p', '{G}p'))
#        #self.parser_test('{X}p', ('p', '{X}p'))
#        #self.parser_test('p&q', ('p', 'q', 'p&q'))
#        #self.parser_test('p|q', ('p', 'q', 'p|q'))
#        #self.parser_test('p{U}q', ('p', 'q', 'p{U}q'))
#        #self.parser_test('p{R}q', ('p', 'q', 'p{R}q'))
#        #self.parser_test('p&q|p', ('p', 'q', 'p&q', 'p&q|p'))
#        #self.parser_test('(p&q)|p', ('p', 'q', 'p&q', '(p&q)|p'))
#        #self.parser_test('(((p&q)|p)|~q)', ('p', 'q', 'p&q', '(p&q)|p','~q', '((p&q)|p)|~q'))
#        #self.parser_test('(((p&q)|p)|{F}~q)', ('p', 'q', 'p&q', '(p&q)|p','~q','{F}~q','((p&q)|p)|{F}~q'))
#        #self.parser_test('~(p&q)|(~p|~q)', ('p', 'q', '~p', '~q','p&q','~(p&q)', '~p|~q', '~(p&q)|(~p|~q)'))
#
#class ltl_ast_test:
#    def test(self):
#        pass

if __name__ == "__main__":
    unittest.main()

