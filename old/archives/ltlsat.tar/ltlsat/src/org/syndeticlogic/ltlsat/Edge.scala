package org.syndeticlogic.ltlsat

class Edge {
    var neighbors: List[Vertex] = Nil
    
    def addVertex(v: Vertex): Unit = {
        val e: Int = 2
        neighbors = v :: neighbors 
    }
}