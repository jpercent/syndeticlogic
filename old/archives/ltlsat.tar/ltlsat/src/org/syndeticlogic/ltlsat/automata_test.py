#!/usr/bin/env python

import unittest
import automata
import transitioners

class automaton_test(unittest.TestCase):
    #def test_dfa(self):
    #    t = {}
    #    alpha = 'alpha'
    #    beta = 'beta'
    #    symbols = (alpha, beta)
    #    states = set((1, 2, 3))
    #    f = set(((2,3),))
    #    i = 1
    #    for j in states:
    #        t[j] = {}
    #       
    #    t[1][alpha] = 2
    #    t[2][beta] = 3
    #    t[2][beta] = 2
    #    t[3][alpha] = 3
    #    delta = lambda x, y: t[x][y]
    #    transitioner = transitioners.simple_transitioner(delta)
    #    
    #    automaton = automata.gbuchi(symbols, states, transitioner, i, f)
    #    #automaton.display()
    #    omega_word = (alpha,beta,beta,beta,beta,beta)
    #    automaton.consume_symbols(omega_word)
    #    self.assertTrue(automaton.accepting())
    #    omega_word = (alpha, alpha, alpha, alpha, alpha)
    #    automaton.reset()
    #    automaton.consume_symbols(omega_word)
    #    self.assertTrue(automaton.accepting())    
    #def test_nda(self):
    #    t = {}
    #    alpha = 'alpha'
    #    beta = 'beta'
    #    symbols = (alpha, beta)
    #    states = set((1, 2, 3))
    #    f = set(((2,3),))
    #    i = set((1,))
    #    for j in states:
    #        t[j] = {}
    #       
    #    t[1][alpha] = (2, 3)
    #    t[2][beta] = (2,)
    #    t[3][alpha] = (3,)
    #    delta = lambda x, y: t[x][y]
    #    transitioner = transitioners.nondeterministic_transitioner(delta)
    #    
    #    automaton = automata.gbuchi(symbols, states, transitioner, i, f)
    #    #automaton.display()
    #    omega_word = (alpha,beta,beta,beta,beta,beta)
    #    automaton.consume_symbols(omega_word)
    #    self.assertTrue(automaton.accepting())
    #    omega_word = (alpha, alpha, alpha, alpha, alpha)
    #    automaton.reset()
    #    automaton.consume_symbols(omega_word)
    #    self.assertTrue(automaton.accepting())
    def test_gbuchi(self):
        t = {}
        alpha = 'alpha'
        beta = 'beta'
        symbols = (alpha, beta)
        states = set((1, 2, 3))
        f = set(((2,3),))
        i = set((1,))
        for j in states:
            t[j] = {}
           
        t[1][alpha] = (2, 3)
        t[2][beta] = (2,)
        t[3][alpha] = (3,)
        delta = lambda x, y: t[x][y]
        transitioner = transitioners.nondeterministic(delta)
        
        automaton = automata.gbuchi(symbols, states, transitioner, i, f)
        #automaton.display()
        omega_word = (alpha,beta,beta,beta,beta,beta)
        automaton.consume_symbols(omega_word)
        self.assertTrue(automaton.accepting())
        omega_word = (alpha, alpha, alpha, alpha, alpha)
        automaton.reset()
        automaton.consume_symbols(omega_word)
        self.assertTrue(automaton.accepting())


if __name__ == "__main__":
    unittest.main()
    
