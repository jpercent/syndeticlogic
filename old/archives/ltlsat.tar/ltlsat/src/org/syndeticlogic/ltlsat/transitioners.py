#!/usr/bin/env python

class deterministic:
    def __init__(self, tfunc):
        self.tfunc = tfunc
    def transition(self, current_state, symbol):
        next_state = None
        try:
            next_state = self.tfunc(state, symbol)
        except KeyError:
            print ' Error no transition from ', str(state), ' with ', str(symbol),' available '
        return next_state

class nondeterministic:
    def __init__(self, tfunc):
        self.tfunc = tfunc
    def transition(self, current_set, symbol):
        result_set = set()
        try:
            for i in current_set:
                next_state = None
                try:
                    next_states = self.tfunc(i, symbol)
                    result_set = result_set.union(next_states)
                except KeyError:
                    pass
        except TypeError:
            pass
        return result_set
