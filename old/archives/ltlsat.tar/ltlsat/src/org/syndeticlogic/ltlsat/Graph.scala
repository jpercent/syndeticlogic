/**
 * 
 */
package org.syndeticlogic.ltlsat

/**
 * @author percent
 */
class Graph(usurper: Int) {
    require(true)
    val this.usurper = usurper
    
    def addVertex(v: Vertex): Unit = {
        
    }
    
    def addDirected(v: Vertex, v1: Vertex) = {
        
    }
}