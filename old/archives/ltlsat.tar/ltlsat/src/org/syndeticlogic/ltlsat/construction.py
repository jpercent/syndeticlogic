#!/usr/bin/env python

import transitioners
import automata
import graph
import formulae
import alphabet

class final_state_constructor:
    def append_state(self, state, final_states):
        formulas = state.get_state()
        for i in formulas:
            if i.get_type() == formulae.UNTIL:
                lhs, rhs = i.get_children()
                eventuallity_satisfied = False
                for j in formulas:
                    if j.get_formula() == rhs.get_formula():
                        eventuallity_satisfied = True
                        break
                if eventuallity_satisfied == False:
                    return
        #print ' adding final state: ', state.get_name()
        final_states.append(state)
    def construct_final_states(self, states):
        final_states = []
        for v in states:
            self.append_state(v, final_states)
        return final_states

class initial_state_constructor:
    def compute_initial_states(self, states, formula):
        initial_states = []
        for i in states:
            #if type(i.get_state()) == tuple:
            for j in i.get_state():
                if j.get_formula() == formula.get_formula():
                    #print ' appending to initial states: ', i.get_state(), ':', i.get_name()
                    initial_states.append(i)
                    break
            #else:
            #    if i.get_state().get_formula() == self.formula.get_formula():
            #        print ' appending to initial states: ', i.get_state()
            #        initial_states.append(i)
        #print 'initial states: ', initial_states
        return initial_states

class state_constructor:
    def conjunction_cond_met(self, lhs, rhs):
        ret = False
        if lhs and rhs:
            ret = True
        return ret
    def disjunction_cond_met(self, lhs, rhs):
        ret = False
        if lhs or rhs:
            ret = True
        return ret
    def until_cond_met(self, lhs, rhs):
        ret = False
        # either 
        if ((lhs or rhs) and (not (lhs and rhs))):
            ret = True
        return ret
    def bin_op_state_check(self, formula_set, bin_op, condition_met):
        operands = bin_op.get_children()
        assert operands.__len__() == 2
        # XXX - h4x0r the subformulae lose the enclosed parens, so we
        # need to check for them
        
        lhs, rhs = False, False
        flhs = operands[0].get_formula()
        frhs = operands[1].get_formula() 
        
        for k in formula_set:
            enclosed_k = formulae.subformula(k)
            fk = k.get_formula()
            fek = enclosed_k.get_formula()
            #print 'testing: k, op0, op1: ', fk,'-',fek,':', flhs, frhs
            if fk == bin_op.get_formula():
                continue
            elif fk == flhs or fek == flhs:
                lhs = True
            elif fk == frhs or fek == frhs:
                rhs = True
                
        ret = condition_met(lhs, rhs)
        #print ' condition met: lhs, rhs' , ret, lhs, rhs
        return condition_met(lhs, rhs)
    def create_state(self, states, subformulae):
        state_name = ''
        is_first_iteration = True
        for j in subformulae:
            if j.get_type() == formulae.CONSTANT and j.get_formula() == '-F-':
                return
            if j.get_type() == formulae.CONJUNCTION:
                if not self.bin_op_state_check(subformulae, j, self.conjunction_cond_met):
                    return
            if j.get_type() == formulae.DISJUNCTION:
                if not self.bin_op_state_check(subformulae, j, self.disjunction_cond_met):
                    return
            if j.get_type() == formulae.UNTIL:
                if not self.bin_op_state_check(subformulae, j, self.until_cond_met):
                    return
            # add a comma to t3h end, except on the first iteration
            if not is_first_iteration:
                state_name += ','
            else:
                is_first_iteration = False
            state_name += j.get_formula()
        states.append(graph.vertex(state_name, subformulae))
        #print ' adding new state, name == -->', state_name, '<--'
    def compute_states(self, formula):
        subformulae_powerset = formula.get_subformulae_powerset()
        #print ' power set ', subformulae_powerset
        #return
        states = []
        for i in tuple(subformulae_powerset):
            #for j in i:
            #    print '\t', j.get_formula()
            self.create_state(states, i)
        return states

class transition_function_constructor:
    def negation_present(self, formula, state):
        ret = False
        negation = formula.negate()
        for i in state:
            if negation.get_formula() == i.get_formula():
                ret = True
                break            
        return ret
    def handle_propostion(self, formula, state, state_name, states, g,
                          alpha):
        if negation_present(formula, state) == False:
            for dest in states:
                edge = g.get_edge(state_name, dest.get_name())
                if edges == None:
                    multi_symbol = multi_symbol(alpha.get_propositional_map(),
                                                alpha.get_valuation_map,
                                                alpha.get_symbol_alphabet(),
                                                formula.get_formula())
                    g.add_edge(state_name, dest.get_name(), symbol)
                else:
                    edge.get_symbol().require_proposition(i.get_formula())
        else:
            print ' prop & its negation present '
            state.set_deadend()
    def construct_transitions(self, state, state_name, states, g, alpha):
        for i in state:
            if state.is_deadend():
                return
            if i.get_type() == formulae.PROPOSITION:
                handle_proposition(i, state, state_name, states, g, alpha)
            elif i.get_type() == formulae.NEGATION:
                raise AssertionError
            elif i.get_type() == formulae.NEXT:
                raise AssertionError
                operand = i.get_children[0]
                for j in states:
                    s = j.get_state()
                    for k in s:
                        if operand.get_formula() == k.get_formula():
                            edge = g.get_edge(state_name, k.get_formula())
                            if edge == None:
                                symbol = create_a_new_multiplex_symbol()
                                symbol.add_remaining_combinatorial_valuations()
                                g.add_edge(state_name, j.get_name(), symbol)
                            else:
                                edge.get_symbol().add_all_possible_valuations()
                # if you find a proposition in the state; must add
                # all other propositions
            elif i.get_type() == formulae.UNTIL:
                raise AssertionError
                # if you find a proposition in the state; must add
                # all other propositions
                lhs_operand, rhs_operand = i.get_children()
                for j in state:
                    if lhs_operand.get_formula() == j.get_formula():
                        for k in states:
                            contains = self.contains_formula(k.get_state(), i)
                            if contains:
                                g.add_edge(state_name, k.get_name(), 'lambda')
                        # the until requirement is not satisfied
                        break
                    if rhs_operand.get_formula() == j.get_formula():
                        # this satisfies the requirement for until
                        break
            elif i.get_type() == formulae.RELEASES:
                raise AssertionError
    def contains_formula(self, state, formula):
        ret = False
        #print state
        for i in state:
            if i.get_formula() == formula.get_formula():
                ret = True
                break
        return ret
    def construct_transition_function(self, alpha, states):
        # construct propositions
        vertices = {}
        for i in states:
            vertices[i.get_name()] = i
            print 'adding vertex', i.get_name()
        g = graph.graph(vertices)
        for vertex in states:
            state = vertex.get_state()
            print state, ':', vertex.get_name()
            self.construct_transitions(state, vertex.get_name(),
                                       states, g, alpha)
        #g.display_tableau()
        j4m35_r0x0rz = g.get_tableau()
        delta = lambda x, y:  j4m35_r0x0rz[x][y]
        transition_function = transitioners.nondeterministic(delta)
        return transition_function


class gbuchi_constructor:
    def __init__(self):
        self.ac = None
        self.sc = state_constructor()
        self.isc = initial_state_constructor()
        self.fsc = final_state_constructor()
        self.tfc = transition_function_constructor()
    def construct_automaton(self, formula):
        propositions = set()
        for i in formula.get_subformulae():
            if i.get_type() == formulae.PROPOSITION:
                propositions.add(i)
            elif i.get_type() == formulae.NEGATION:
                # XXX - t3h h4x0r
                propositions.add(i.negate())
        print ' propositions ', propositions
        self.ac = alphabet.alphabet_computer(list(propositions))
        
        final_states = []
        #alphabet_map = self.ac.compute_symbol_alphabet(formula)
        states = self.sc.compute_states(formula)
        #for i in states:
            #print '--->',i.get_name(), '<---'
        initial_states = self.isc.compute_initial_states(states, formula)
        #for i in initial_states:
            #print '--->',i.get_name(), '<---'        
        delta = self.tfc.construct_transition_function(states, self.ac)
        return
        final_states = self.fsc.construct_final_states(states)
        #for i in final_states:
            #print '--->', i.get_name(), '<---'

        
        automaton = automata.gbuchi(alphabet,
                                    states,
                                    delta,
                                    initial_states,
                                    final_states)
        return automaton
    
class buchi_tableau:
    def construct_tableau(self, vertice_map):
        tableau = {}
        vertices = vertice_map.values()
        for vertex in vertices:
            src_name = vertex.get_name()
            edges = vertex.get_edges()
            tableau[src_name] = {}
            for e in edges:
                dest_name = e.traverse().get_name()
                multi_sym = e.edge_symbol().get_symbol_set()
                for s in list(multi_sym):
                    try:
                        tableau[src_name][s.compute_symbol()] += (dest_name,)
                    except KeyError:
                        tableau[src_name][s.compute_symbol()] = ()
                        tableau[src_name][s.compute_symbol()] += (dest_name,)
        return tableau
    def display_tableau(self, vertice_map):
        t = self.construct_tableau(vertice_map)
        vertices = vertice_map.values()
        for vertex in vertices:
            for e in vertex.get_edges():
                src_name = vertex.get_name()
                multi_sym = e.edge_symbol().get_symbol_set()
                for s in list(multi_sym):
                    print 'delta(',src_name,',',s.compute_symbol(),')=',\
                            t[src_name][s.compute_symbol()]


class buchi_converter:
    def convert_gbuchi(self, gbuchi):
        return gbuchi