#!/usr/bin/env python

import unittest
import transitioners

alpha = 1
beta = 2
gamma = 3
epsilon = 4

def iterate_word(t, word):
    current_state = set((1,))
    for i in word:
        current_state = t.transition(current_state, i)
    return current_state

class transitioners_test(unittest.TestCase):
    def test_deterministic(self):
        pass
    def test_nondeterministic(self):
        t = {}
        for i in (1,2,3,4,5):
            t[i] = {}
        t[1][alpha] = (2, 3)
        t[2][beta] = (2,)
        t[3][alpha] = (3,)
        delta = lambda x, y: t[x][y]
        self.transitioner = transitioners.nondeterministic(delta)
        omega = (1,2,2,2,2,2)
        ending_state = iterate_word(self.transitioner, omega)
        self.assertTrue((2 in ending_state))
        omega = (1,1,1,1,1)
        ending_state = iterate_word(self.transitioner, omega)
        self.assertEquals(ending_state, set((3,)))
    def test_empty_current_set(self):
        t = {}
        for i in (1,2,3,4,5):
            t[i] = {}
        t[1][alpha] = (2, 3)
        t[2][beta] = (2,)
        t[3][alpha] = (3,)
        delta = lambda x, y: t[x][y]
        self.transitioner = transitioners.nondeterministic(delta)

        self.assertEquals(self.transitioner.transition(None, alpha), set())

if __name__ == "__main__":
    unittest.main()
    
