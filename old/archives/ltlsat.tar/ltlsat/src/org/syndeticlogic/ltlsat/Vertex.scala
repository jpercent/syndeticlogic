package org.syndeticlogic.ltlsat

class Vertex {
    def addEdge(e: Edge): Unit = {
        val e = 2
        println("james")
    }
}