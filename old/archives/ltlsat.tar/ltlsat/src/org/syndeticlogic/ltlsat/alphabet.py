#!/usr/bin/env python

import copy

class multi_symbol:
    def __init__(self, prop_map, alpha_map, alphabet, initial_prop=None,
                 negate=False):
        self.prop_map = prop_map
        self.alpha_map = alpha_map
        self.alphabet = alphabet
        self.symbol_set = set()
        self.prop_set = set()
        self.not_prop_set = set()
        for i in list(self.alphabet):
                self.symbol_set.add(copy.deepcopy(i))
        if initial_prop != None and negate == False:
            self.require_proposition(initial_prop)
            self.prop_set.add(initial_prop)
        elif initial_prop != None and negate == True:
            self.require_not_proposition(initial_prop)
            self.not_prop_set.add(initial_prop)
        #print ' symbol set: \n'
        #for i in list(self.symbol_set):
        #    print '\t', i.compute_symbol()
    def require_proposition(self, prop):
        assert not (prop in self.not_prop_set)
        self.prop_set.add(prop)
        #print 'symbol set before adding prop: ', prop, '\n'
        #for i in list(self.symbol_set):
        #    print 'symbol: ', i.compute_symbol()
        new_sym_set = set()
        for i in list(self.symbol_set):
            i.add_proposition(prop)
            new_sym_set.add(i)
        self.symbol_set = new_sym_set
        #print 'symbol set after: '
        #for i in list(self.symbol_set):
        #    print 'symbol: ', i.compute_symbol()
    def require_not_proposition(self, prop):
        assert not (prop in self.prop_set)
        self.not_prop_set.add(prop)
        new_sym_set = set()
        #print 'symbol set before adding ~prop: ', prop, '\n'
        #for i in list(self.symbol_set):
        #    print 'symbol: ', i.compute_symbol()
        for i in list(self.symbol_set):
            i.remove_proposition(prop)
            new_sym_set.add(i)
        self.symbol_set = new_sym_set
        #print 'symbol set before: '
        #for i in list(self.symbol_set):
        #    print 'symbol: ', i.compute_symbol()
    #def imbue_valid_symbols(self):
    #    alphabet_copy = set()
    #    for i in list(self.alphabet):
    #        alphabet_copy.add(copy.deepcopy(i))
    #    self.symbol_set = alphabet_copy
    #    for i in list(self.prop_set):
    #        self.require_proposition(i)
    def get_symbol_set():
        return self.symbol_set


class symbol:
    def __init__(self, propositional_map, alphabet_map):
        self.propositional_map = propositional_map
        self.alpha_map = alphabet_map
        self.propositions = set()
    def __eq__(self, other):
        assert isinstance(other, symbol)
        if self.propositions == other.propositions:
            return True
        else:
            return False
    def __hash__(self):
        hash = ''.__hash__()
        prop_list = list(self.propositions)
        prop_list.sort()
        for i in prop_list:
            hash += i.__hash__()
        return hash
    def remove_proposition(self, proposition):
        assert proposition != None
        try:
            self.propositions.remove(proposition)
        except KeyError:
            pass
    def add_proposition(self, proposition):
        assert proposition != None
        self.propositions.add(proposition)
    def get_propositions(self, propositions):
            return self.propositions
    def compute_symbol(self):
        valuation = [False, False, False]
        print 'props: ', 
        for i in list(self.propositions):
            valuation[self.propositional_map[i]] = True
        return self.alpha_map[tuple(valuation)]

class alphabet_computer:
    def __init__(self, propositions):
        self.props = propositions
        self.propositional_map = self.__compute_propositional_map__(self.props)
        #print self.propositional_map, ':'
        self.valuations = self.__compute_valuations__(self.props.__len__())
        self.valuation_map = self.__compute_valuation_map__(self.valuations)
        #print self.valuation_map
        self.alphabet = self.__construct_alphabet__(self.propositional_map,
                                               self.valuation_map)
    def __construct_alphabet__(self, prop_map, alpha_map):
        empty_symbol = symbol(prop_map, alpha_map)
        alphabet = set()
        alphabet.add(empty_symbol)
        for i in alpha_map.keys():
            props = set()
            position = 0
            #print ' i ', i 
            for j in prop_map.keys():
                if i[prop_map[j]] == True:
                    props.add(j)
            #print 'props ', props
            new_symbol = symbol(prop_map, alpha_map)
            for j in list(props):
                new_symbol.add_proposition(j)
            alphabet.add(new_symbol)
        #for i in list(alphabet):
        #    print ' symbol: ', i.compute_symbol()
        return alphabet
    def __compute_propositional_map__(self, propositions):
        map = {}
        position = 0
        for i in propositions:
            map[i] = position
            position += 1
        return map
    def __compute_valuation_map__(self, propositional_valuations):
        count = 0
        alpha_map = {}
        for i in propositional_valuations:
            #print i
            alpha_map[i] = count
            count += 1
        return alpha_map
    def __compute_valuations__(self, count):
        if count == 1: # or count == 0:
            return ((False,),(True,))
        else:
            next_valuation = ()
            pvaluation = self.__compute_valuations__((count - 1))
            for i in pvaluation:
                t = i + (False,)
                t1 = i + (True,)
                next_valuation += (t,)
                next_valuation += (t1,)
            return next_valuation
    def get_propositions(self):
        return self.props
    def get_propositional_map(self):
        return self.propositional_map
    def get_valuations(self):
        return self.valuations
    def get_valuation_map(self):
        return self.valuation_map
    def get_symbol_alphabet(self):
        return self.alphabet

if __name__ == '__main__':
    print '-'*80
    props = ['p', 'q', 'r']
    a = alphabet_computer(props)
    sym = symbol(a.get_propositional_map(),
                 a.get_valuation_map())
    print '-'*80
    sym.add_proposition('p')
    print 'symbol: ', sym.compute_symbol()
    sym.add_proposition('q')
    print 'symbol: ', sym.compute_symbol()
    print '\n\n'
    print '-'*80
    for i in a.get_symbol_alphabet():
        print ' symbol: ', i.compute_symbol() 
    print '-'*80
    print '-'*80
    print ' valuation map \n', a.get_valuation_map()
    print ' multi_symbol '
    ms = multi_symbol(a.get_propositional_map(), a.get_valuation_map(),
                      a.get_symbol_alphabet())
    ms.require_proposition('p')
    ms.require_proposition('r')
    ms.require_proposition('q')
    print '-'*80
    print '-'*80
    print ' valuation map \n', a.get_valuation_map()
    print ' multi_symbol '
    ms = multi_symbol(a.get_propositional_map(), a.get_valuation_map(),
                      a.get_symbol_alphabet(), 'p')
    print 'adding r '
    ms.require_proposition('r')

    print '-'*80
    print '-'*80
    print ' valuation map \n', a.get_valuation_map()
    print ' not validation'
    ms = multi_symbol(a.get_propositional_map(), a.get_valuation_map(),
                      a.get_symbol_alphabet(), 'p', True)
    print ' adding r '
    ms.require_proposition('r')
    try:
        ms.require_proposition('p')
    except AssertionError:
        print ' correctly asserted require p '
    else:
        raise
    try:
        ms.require_not_proposition('r')
    except AssertionError:
        print ' correctly asserted require ~r '
    else:
        raise
    ms.require_not_proposition('q')
    #ms.imbue_valid_symbols()
    