#!/usr/bin/env python

import unittest
import formulae
import automaton_construction
import graph

def check_list_contents_equal(unit_test, actual, expected):
        unit_test.assertEqual(actual.__len__(), expected.__len__())
        import copy
        for i in copy.copy(expected):
            found = False
            for j in actual:
                if i == j:
                    expected.remove(i)
                    actual.remove(j)
                    found = True
            if found == False:
                unit_test.assertFalse('check_list_contents_equal: lists not equal')
        unit_test.assertEqual(actual.__len__(),
                              expected.__len__())
        unit_test.assertEqual(expected.__len__(), 0)

class state_constructor_test(unittest.TestCase):
    def do_state_test(self, expected_states, formula):
        sc = automaton_construction.state_constructor()
        states = sc.compute_states(formula)
        self.assertEquals(list, type(states))
        state_names = []
        for i in states:
            state_names.append(i.get_name())
        #for i in states:
        #    print '->',i.get_name()
        #print state_names, '--actual--'
        #print expected_states, '---expected---'
        
        check_list_contents_equal(self, state_names,
                                  expected_states)
        
    def test(self):
        #return
        factory = formulae.formula_factory()
        formula = factory.create_formula('p')
        expected_states = ['', 'p']
        self.do_state_test(expected_states, formula)
        
        formula = factory.create_formula('~p')
        expected_states = ['', 'p', '~p', '~p,p']
        self.do_state_test(expected_states, formula)
        
        formula = factory.create_formula('-T-{U}p')
        expected_states = ['',
                           '-T-{U}p,p',
                           '-T-,p' ,
                           '-T-{U}p,-T-',
                           'p',
                           '-T-']
        self.do_state_test(expected_states, formula)
        
        expected_states = ['',
                        '-T-{U}p,p',
                        '-T-,p' ,
                           '-T-{U}p,-T-',
                           'p',
                           '-T-']
        formula = factory.create_formula('{F}p')
        self.do_state_test(expected_states, formula)
        
        expected_states = ['','~p', 'p', '~p,p', '~p|p,p', '~p|p,~p,p', '~p|p,~p']
        formula = factory.create_formula('p->p')
        self.do_state_test(expected_states, formula)
        

class initial_state_constructor_test(unittest.TestCase):
    def do_test(self, expected_initial_states, formula):
        sc = automaton_construction.state_constructor()
        states = sc.compute_states(formula)
        isc = automaton_construction.initial_state_constructor()
        initial_states = isc.compute_initial_states(states, formula)
        
        istate_names = []
        for i in initial_states:
            istate_names.append(i.get_name())
        check_list_contents_equal(self, istate_names,
                                  expected_initial_states)

        
        #print ' states: '
        #for i in states:
        #    print i.get_name()
        #print ' initial states '
        #for i in initial_states:
        #    print i.get_name()

    def test(self):
        pass
        #print '\n\n\n starting \n\n\n'
        factory = formulae.formula_factory()
        formula = factory.create_formula('p->p')
        exp = ['~p|p,p', '~p|p,~p,p', '~p|p,~p']
        self.do_test(exp, formula)

        formula = factory.create_formula('p&(-T-{U}p)')
        #print formula.get_formula(), ':', formula.get_subformulae()
        exp = ['p&(-T-{U}p),p,-T-{U}p',]
        self.do_test(exp, formula)
        
#
class delta_constructor_test(unittest.TestCase):
    def test(self):
        pass
    
#class final_state_constructor_test(unittest.TestCase):
#    def final_state_constructor_test(self, expected_final_states, formula):
#        fs = formula.get_closure_power_set()
#        state_constructor = ltl2buchi.state_constructor(fs)
#        states = state_constructor.compute_states()
#        for i in states:
#            print i.get_name()
#        test_subject = ltl2buchi.final_state_constructor(states)
#        final_states = test_subject.construct_final_states()
#        for i in final_states:
#            print i.get_name()
#        self.assertEqual(expected_final_states.__len__(), final_states.__len__())
#        for i in expected_final_states:
#            found = False    
#            for j in final_states:
#                if j.get_name() == i:
#                    final_states.remove(j)
#                    found = True
#            if not found:
#                print 'error initial state: -->'+i.__str__()+'<-- not found'
#                self.assertTrue(found)
#    def test(self):
#        self.final_state_constructor_test(['q,p','q', 'p', 'q,p,p&q'], ltl.formula('p&q'))
#        self.final_state_constructor_test(['q,p','q', 'p', 'q,p{U}q'], ltl.formula('p{U}q'))

#
#class ltl2buchi_test(unittest.TestCase):
#    def get_alphabet_test(self, expected_alphabet, formula):
#        converter = ltl2buchi.ltl2buchi(formula)
#        alpha = converter.get_alphabet()
#        self.assertEqual(alpha.__len__(), expected_alphabet.__len__())
#        for i in expected_alphabet:
#            found = False
#            for j in alpha:
#                if j == i:
#                    found = True
#            if not found:
#                print 'error alphabet does not include: ', i
#                self.assertTrue(found)
#    def get_model_alphabet_test(self, expected_alphabet, formula):
#        converter = ltl2buchi.ltl2buchi(formula)
#        model_alphabet = converter.get_model_alphabet()
#        self.assertEqual(model_alphabet.__len__(), expected_alphabet.__len__())
#        for i in expected_alphabet:
#            found = False
#            for j in model_alphabet:
#                if j == i:
#                    found = True
#            if not found:
#                print 'error alphabet does not include: ', i
#                self.assertTrue(found)
#    def test_alphabet(self):
#        self.get_alphabet_test(['p', 'p&~q', '~q', 'q', 'lambda'], ltl.formula('p&~q'))
#        self.get_alphabet_test(['p', 'lambda'], ltl.formula('p'))
#        self.get_alphabet_test(['p', '~p', 'lambda'], ltl.formula('~p'))
#        self.get_alphabet_test(['p', '~p', '{F}q', 'q', '~p&{F}q', 'lambda'], ltl.formula('~p&{F}q'))
#    def test_model_alphabet(self):    
#        self.get_model_alphabet_test(((0,0),(0,1),(1,0),(1,1)), ltl.formula('p&q'))
#        self.get_model_alphabet_test(((0, 0, 0), (0, 0, 1),
#           (0, 1, 0), (0, 1, 1), (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)),
#            ltl.formula('p&q&z'))
#        self.get_model_alphabet_test(((0, 0, 0, 0), (0, 0, 0, 1), (0, 0, 1, 0),
#           (0, 0, 1, 1), (0, 1, 0, 0), (0, 1, 0, 1), (0, 1, 1, 0),
#            (0, 1, 1, 1), (1, 0, 0, 0), (1, 0, 0, 1), (1, 0, 1, 0),
#            (1, 0, 1, 1), (1, 1, 0, 0), (1, 1, 0, 1), (1, 1, 1, 0),
#            (1, 1, 1, 1)), ltl.formula('p&q&z|f'))
#    def transition_test(self):
#        print ' ------- \n\n\n -------'
#        converter = ltl2buchi.ltl2buchi(ltl.formula('p&q'))
#        inits = converter.get_initial_states()
#        #for i in inits:
#        #    print i.get_name()
#        converter.get_delta()
#        converter.get_final_states()

if __name__ == '__main__':
    unittest.main()