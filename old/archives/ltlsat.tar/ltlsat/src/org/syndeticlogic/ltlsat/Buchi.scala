package org.syndeticlogic.ltlsat

class Buchi(s: List[Int]) {
    val states = s
    var arcs: List[(Int, Int)] = Nil
    
    def addArc(from: Int, to: Int) = {
        arcs = (from, to) :: arcs
    }
    
    def hasStronglyConnectedComponent(): Boolean = {
        return true //arcs.foreach(arc => dfs(arc))
    }

    /*def dfs((Int, Int)): Boolean = {
     return true   
    }*/
}