#!/usr/bin/env python

import formulae_parser
from formulae_defines import *

class formula_factory:
    def create_formula(self, phi):
        parser = formulae_parser.parser()
        handler = formula_ast()
        #print ' parse formula: ', phi
        parser.parse(phi, handler)
        formula = handler.get_tree()        
        return formula

class formula_ast(formulae_parser.default_syntax_tree):
    def __init__(self):
        self.root = None
    def get_tree(self):
        return self.root
    def lookup(self, element, root):
        ret = None
        if type(root) != formula:
            return ret
        elif root.get_children().__len__() == 0:
            assert root.get_type() == PROPOSITION or root.get_type() == CONSTANT
            if root.get_formula() == element:
                ret = root
        else:
            for i in root.get_children():
                ret = self.lookup(element, root)
                if ret != None:
                    return ret
        return ret
    def binary(self, lhs, operator, rhs, type):
        if type == IMPLIES:
            lhs = lhs.negate()
            operator = '|'
            type = DISJUNCTION
        #print ' parse-binary: lhs-operand-rhs-type', lhs, operator, rhs, type
        bin = binary(lhs, operator, rhs, type)
        self.root = bin
        return bin
    def unary(self, operator, operand, type):
        #print ' parse-unary: operator-operand-type', operator, operand, type
        if operator == '{F}':
            self.root = self.binary(self.constant('-T-', True), '{U}', operand,
                                    UNTIL)
        elif operator == '{G}':
            self.root = self.binary(self.constant('-F-', False), '{R}', operand,
                                    RELEASES)
        elif operator == '~' and operand.get_composition() == COMPOSITE:
            #print ' here '
            self.root = operand.negate()
        else:
            self.root = unary(operator, operand, type)
        return self.root
    def prop(self, element):
        prop = self.lookup(element, self.root)
        if prop == None:
            prop = proposition(element, False)
        #print ' parse-prop: ', prop, element
        self.root = prop
        return prop
    def constant(self, element, value):
        const = self.lookup(element, self.root)
        if const == None:
            const = constant(element, value)
        assert const.get_value() == value
        #print ' parse-constant: ',const,  element
        self.root = const
        return const
    def subformula(self, lparen, formula, rparen):
        sub = subformula(formula)
        self.root = sub
        #print ' parse-enclosed-formula: ', lparen, sub, rparen
        return sub

class subformulae_visitor:
    def __init__(self):
        self.subformulae = ()
    def find(self, declf):
        ret = False
        for i in self.subformulae:
            if declf == i:
                ret = True
        return ret
    def visit_decl(self, declf):
        found = self.find(declf)
        if not found:
            self.subformulae += (declf,)
    def visit_unary(self, unaryf):
        assert unaryf.get_children().__len__() == 1
        self.subformulae += (unaryf,)
        if unaryf.get_type() != NEGATION:
            self.visit_node(unaryf.get_children()[0])
    def visit_subformula(self, subf):
        assert subf.get_children().__len__() == 1
        self.visit_node(subf.get_children()[0])        
    def visit_binary(self, binaryf):
        assert binaryf.get_children().__len__() == 2
        self.subformulae += (binaryf,)
        self.visit_node(binaryf.get_children()[0])
        self.visit_node(binaryf.get_children()[1])
    def visit_node(self, node):
        node.accept(self)

class formula:
    def __init__(self, original_string, formula_type, composition):
        self.original_string = original_string
        self.type = formula_type
        self.composition = composition
        self.subformulae = None
        self.subformulae_powerset = None
        self.children = []
    def __eq__(self, other):
        # XXX for now == equals string equality; however, perhaps entailment is
        # a more meangingful equality definition
        if self.get_formula() == other.get_formula():
            return True
        else:
            return False
    def __hash__(self):
        return self.get_formula().__hash__()
    def __compute_subformulae__(self):
        visitor = subformulae_visitor()
        self.accept(visitor)
        self.subformulae = visitor.subformulae
    def __compute_subformulae_powerset__(self):
        # wh0'5 y0ur d4ddi3
        self.subformulae_powerset = ()
        for i in range(2 ** len(self.subformulae)):
            subset = ()
            for j in range(len(self.subformulae)):
                if i & 2 ** j:
                    subset += (self.subformulae[j],)
            self.subformulae_powerset += (subset,)
        #print self.subformulae_powerset
    def get_formula(self):
        return self.original_string
    def get_type(self):
        return self.type
    def get_composition(self):
        return self.composition
    def get_children(self):
        return self.children
    def get_subformulae(self):
        return self.subformulae
    def get_subformulae_powerset(self):
        return self.subformulae_powerset
    def set_type(self, type):
        self.type = type
    def accept(self, visitor):
        return None
    def satisfiable(self):
        # phi is SAT iff the language represented by automaton construct from
        # phi is not empty.  phi is SAT iff L(Aphi) != 0 
        import construction
        gbc = construction.gbuchi_constructor()
        bc = construction.buchi_converter()
        gbuchi = gbc.construct_automaton(self)
        #buchi = bc.convert_gbuchi(gbuchi)
        #return buchi.emptiness()
        return None
    def entails(self, psi):
        # build a formula that is self.get_formula() & ~(psi.get_formula()),
        # generate an automaton of said formula and check if it's empty.
        pass

class constant(formula):
    def __init__(self, name, value):
        assert name != None
        formula.__init__(self, name, CONSTANT, PRIME)
        self.value = value
        self.__compute_subformulae__()
        self.__compute_subformulae_powerset__()
    def get_value(self):
        return self.value
    def negate(self):
        return unary('~', self, NEGATION)
    def accept(self, visitor):
        visitor.visit_decl(self)

class proposition(constant):
    def __init__(self, prop, value=0):
        assert prop != None
        formula.__init__(self, prop, PROPOSITION, PRIME)
        self.value = value
        self.__compute_subformulae__()
        self.__compute_subformulae_powerset__()
    def set_value(self, value):
        self.value = value

class unary(formula):
    def __init__(self, operator, operand, type):
        assert operator != None
        assert operand != None
        assert type != None
        #print ' unary: ', operator+operand.get_formula()
        formula.__init__(self, operator+operand.get_formula(), type, COMPOSITE)
        self.operator = operator
        self.children.insert(0, operand)
        self.__compute_subformulae__()
        self.__compute_subformulae_powerset__()
        assert self.children.__len__() == 1
    def get_operator(self):
        return self.operator
    def negate(self):
        if self.type == NEGATION:
            return self.children[0]
        else:
            operand = self.children[0]
            negation = unary(self.operator, operand.negate(), type)
            return negation
    def accept(self, visitor):
        visitor.visit_unary(self)

class binary(formula):
    def __init__(self, lhs, operator, rhs, type):
        assert lhs != None
        assert operator != None
        assert rhs != None
        assert type != None
        formula.__init__(self, lhs.get_formula()+operator+rhs.get_formula(),
                         type, COMPOSITE)
        self.operator = operator
        self.children.insert(0,lhs)
        self.children.insert(1,rhs)
        self.operator_dual = {RELEASES_OP:UNTIL_OP, UNTIL_OP:RELEASES_OP,
                 CONJUNCTION_OP:DISJUNCTION_OP, DISJUNCTION_OP:CONJUNCTION_OP}
        self.type_dual = { RELEASES:UNTIL, UNTIL:RELEASES,
             CONJUNCTION:DISJUNCTION, DISJUNCTION:CONJUNCTION}
        self.__compute_subformulae__()
        self.__compute_subformulae_powerset__()
        assert self.children.__len__() == 2
    def get_operator(self):
        return self.operator
    def negate(self):
        #print ' binary negation '
        new_type = self.type_dual[self.type]
        new_operator = self.operator_dual[self.operator]
        new_lhs = self.children[0].negate()
        new_rhs = self.children[1].negate()
        if self.type == UNTIL or self.type == RELEASES:
            negation = binary(new_rhs, new_operator, new_lhs, new_type)
        else:
            negation = binary(new_lhs, new_operator, new_rhs, new_type)
        return negation
    def accept(self, visitor):
        visitor.visit_binary(self)

class subformula(formula):
    def __init__(self, phi):
        assert phi != None
        formula.__init__(self, '('+phi.get_formula()+')', SUBFORMULA, COMPOSITE)
        self.children.insert(0,phi)
        self.__compute_subformulae__()
        self.__compute_subformulae_powerset__()
        assert self.children.__len__() == 1
    def negate(self):
        #print ' subformula negation '
        negation = subformula(self.children[0].negate())
        return negation
    def accept(self, visitor):
        visitor.visit_subformula(self)
