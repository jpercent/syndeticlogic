#!/usr/bin/python
import os

os.system('./automata_test.py')
os.system('./formulae_test.py')
os.system('./formulae_parser_test.py')
os.system('./graph_test.py')
os.system('./transitioners_test.py')
#os.system('./automaton_construction_test.py')

