#!/usr/bin/env python

import unittest
import graph
import transitioners
import automata
import BitVector

class edge_test(unittest.TestCase):
    def test(self):
        v = graph.vertex('myvertex')
        v1 = graph.vertex('myothervertex')
        e = graph.edge(v1, v, 'p')
        self.assertEqual(e.dest(), v)
        e = graph.edge(v, v1,'q')
        self.assertEqual(e.dest(), v1)
        e1 = graph.edge(v, v1, 1337)
        self.assertEqual(1337, e1.edge_symbol())
        self.assertEqual(e, e1)
        self.assertEqual(e.__hash__(), e1.__hash__())
        
        
class vertex_test(unittest.TestCase):
    def test(self):
        v = graph.vertex('me')
        v1= graph.vertex('him')
        v2= graph.vertex('her')
        v.add_edge(graph.edge(v, v1))
        v.add_edge(graph.edge(v, v2))
        v.add_edge(graph.edge(v, v))
        v1.add_edge(graph.edge(v1, v))
        v2.add_edge(graph.edge(v2,v))
        # XXX fix me
        #edges = v.get_edges()
        #self.assertEquals(edges[0].dest(), v1)
        #self.assertEquals(edges
        #self.assertEquals(edges[0].dest().get_name(), 'him')
        #
        #self.assertEquals(edges[1].dest(), v2)
        #self.assertEquals(edges[1].dest().get_name(), 'her')
        #
        #self.assertEquals(edges[2].dest(), v)
        #self.assertEquals(edges[2].dest().get_name(), 'me') 
        #
        #node = edges[0].dest()
        #edges = node.get_edges()
        #self.assertEquals(edges[0].dest(), v2)
        #self.assertEquals(edges[0].dest().get_name(), 'her')
        #
        #node = edges[0].dest()
        #edges = node.get_edges()
        #self.assertEquals(edges[0].dest(), v)
        #self.assertEquals(edges[0].dest().get_name(), 'me')
        
class graph_test(unittest.TestCase):
    def fill_tableau(self, states, symbols, table):
        for i in states:
            for j in symbols:
                try :
                    #print i , j , 'table ',
                    table[i][j]
                except KeyError:
                    table[i][j] = None
    def test(self):
        v = graph.vertex('me')
        v1= graph.vertex('him')
        v2= graph.vertex('her')
        vertices = {v.get_name():v, v1.get_name():v1, v2.get_name():v2}
        g = graph.graph(vertices)
        g.add_edge('me', 'him', 0)
        g.add_edge('me', 'her', 1)
        g.add_edge('me', 'me', 0)
        g.add_edge('him', 'her', 1)
        g.add_edge('her','her', 1)
        
        symbols = (0, 1)
        # w3 1ik35 h3r 8357
        states = set(('me', 'him', 'her'))
        final = set((('me','her'),))
        initial = set(('me',))
        
        table = g.construct_tableau()
        g.display_tableau()
        delta = lambda x,y: table[x][y]
        d3174 = transitioners.nondeterministic(delta)
        
        #g.display_tableau()
        automaton = automata.gbuchi(symbols, states, d3174, initial, final)
        #automaton.display()
        omega_word = (0,0,0,0,1,1,1,1)
        automaton.consume_symbols(omega_word)
        self.assertTrue(automaton.accepting())
        omega_word = (1,1,1,1,1,1,1)
        automaton.reset()
        automaton.consume_symbols(omega_word)
        self.assertTrue(automaton.accepting())

if __name__ == "__main__":
    unittest.main()