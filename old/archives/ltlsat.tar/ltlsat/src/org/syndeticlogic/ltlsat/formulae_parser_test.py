#!/usr/bin/env python

import unittest
import formulae
import formulae_parser

class formulae_parser_test(unittest.TestCase):
    def parser_test(self, phi, expected):
        parser = formulae_parser.parser()
        handler = formulae_parser.default_syntax_tree()
        parser.parse(phi, handler)
        actual = handler.get_tree()
        #print actual
        for i in range(expected.__len__()):
            for j in range(expected[i].__len__()):
                self.assertEquals(expected[i][j], actual[i][j])
                # 4nd y0ur f47h3r i5 wh0?
    def test(self):
        true_c = (formulae.CONSTANT, '-T-')
        false_c = (formulae.CONSTANT, '-F-')
        prop_p = (formulae.PROPOSITION, 'p')
        prop_q = (formulae.PROPOSITION, 'q')
        negation_p = (formulae.NEGATION, '~', 'p')
        con_npandq = (formulae.CONJUNCTION, '~p', '&', 'q')
        disj_qornp = (formulae.DISJUNCTION, 'q', '|', '~p')
        sub_p = (formulae.SUBFORMULA, '(', 'p', ')')
        sub_disj_qornp = (formulae.SUBFORMULA, '(', 'q|~p',')')
        freleases_sub_disj_qornp = (formulae.RELEASES, '-F-', '{R}', '(q|~p)')
        eventually_sub_disj_qornp = (formulae.EVENTUALLY, '{F}', '(q|~p)')
        next_true = (formulae.NEXT, '{X}', '-T-')
        true_until_p = (formulae.UNTIL, '-T-', '{U}','p')
        p_implies_q =(formulae.IMPLIES,'p','->','q')
        p_con_q = (formulae.CONJUNCTION,'p','&','q')
        globally_q = (formulae.GLOBALLY,'{G}','q')
        
        expected = [true_c]
        self.parser_test('-T-', expected)
        expected = [false_c]
        self.parser_test('-F-', expected)
        
        expected = [prop_p]
        self.parser_test('p', expected)
        
        expected = [prop_p, negation_p]
        self.parser_test('~p', expected)
        
        expected = [prop_p, negation_p, prop_q, con_npandq]
        self.parser_test('~p&q', expected)
        
        expected = [prop_q, prop_p, negation_p, disj_qornp]
        self.parser_test('q|~p', expected)

        expected = [prop_p, sub_p]
        self.parser_test('(p)', expected)
        
        expected = [prop_q, prop_p, negation_p, disj_qornp, sub_disj_qornp]
        self.parser_test('(q|~p)', expected)
        
        expected = [false_c, prop_q, prop_p, negation_p, disj_qornp,
                    sub_disj_qornp, freleases_sub_disj_qornp]
        self.parser_test('-F-{R}(q|~p)', expected)
        #self.parser_test('~p|q&~(p|q)', )
        
        expected = [prop_q, prop_p, negation_p, disj_qornp, sub_disj_qornp,
                    eventually_sub_disj_qornp]
        self.parser_test('{F}(q|~p)',expected)
        
        expected = [true_c, next_true]
        self.parser_test('{X}-T-',expected)
        
        expected = [true_c, prop_p, true_until_p]
        self.parser_test('-T-{U}p',expected)
        
        expected = [prop_p, prop_q, p_implies_q]
        self.parser_test('p->q',expected)
        
        expected = [prop_p, prop_q, p_con_q]
        self.parser_test('p&q',expected)
        
        expected = [prop_q, globally_q]
        self.parser_test('{G}q',expected)

if __name__ == "__main__":
    unittest.main()

