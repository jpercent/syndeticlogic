#!/usr/bin/env python

class gbuchi:
    def __init__(self, symbols, states, delta, initial_states, finals):
        self.symbols = symbols
        self.states = states
        self.delta = delta
        self.finals = finals
        self.initial_states = initial_states
        self.current_states = initial_states
    def copy(self):
        import copy
        return copy.deepcopy(self)
    def reset(self):
        self.current_states = self.initial_states
    def consume_symbols(self, partial_omega_word):
        for symbol in partial_omega_word:
            self.current_states = self.delta.transition(self.current_states, symbol) 
    def accepting(self):
        for i in self.current_states:
            for j in self.finals:
                if (i in j):
                    return True
        return False
    def intersection(self, other):
        return self
    def emptiness(self):
        hash = set()
        for i in self.initial_states:
            if self.__depth_first_search_pass1__(i, hash) == True:
                return True
        return False
    def __depth_first_search_pass1__(self, state, pass1_hash):
        pass1_hash.add(state)
        for i in state.get_edges():
            successor = i.traverse()
            if not pass1_hash.issuperset([successor,]):
                if self.__depth_first_search_pass1__(successor, pass1_hash) == True:
                    return True
            pass2_hash = set()
            if self.__depth_first_search_pass2__(successor, pass1_hash, pass2_hash) == True:
                return True
        return False
    def __depth_first_search_pass2__(self, state, pass1_hash, pass2_hash):
        pass1_hash.add(state)
        for i in  state.get_edges():
            successor = i.traverse()
            if pass1_hash.issuperset([successor,]):
                return True
            elif not pass2_hash.issuperset([successor,]):
                self.__depth_first_search_pass2(state, pass1_hash, pass2_hash)
        return False
    def display(self):
        print 'alphabet: '+str(self.symbols)
        print 'states: '+str(self.states)
        delta = lambda x, y: self.delta.transition(set((x,)),y)
        print 'transition function: '
        for state in self.states:
            for symbol in self.symbols:
                print '\t'+'delta('+str(state)+','+str(symbol)+')='+str(delta(state, symbol))
        print 'initial states: '+str(self.initial_states)
        print 'final states: '+str(self.finals)
        

