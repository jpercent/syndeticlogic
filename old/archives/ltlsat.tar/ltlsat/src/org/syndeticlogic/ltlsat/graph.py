#!/usr/bin/env python

class edge:
    def __init__(self, src_vertex, dest_vertex, symbol=None):
        assert isinstance(src_vertex, vertex)
        assert isinstance(dest_vertex, vertex)
        self.start_vertex = src_vertex
        self.end_vertex = dest_vertex
        self.symbol = symbol
    def src(self):
        return self.start_vertex
    def dest(self):
        return self.end_vertex
    def __eq__(self, other):
        if self.start_vertex == other.start_vertex \
           and self.end_vertex == other.end_vertex:
            return True
        else:
            return False
    def __hash__(self):
        sn = self.start_vertex.get_name()
        en = self.end_vertex.get_name()
        hashv = sn.__hash__() + en.__hash__()
        return hashv
    def edge_symbol(self):
        return self.symbol

class vertex:
    def __init__(self, name, state=None):
        self.name = name
        self.state = state
        self.edges = set()
        self.deadend = False
    def add_edge(self, e):
        assert e.src() == self
        self.edges.add(e)
    def get_edges(self):
        return self.edges
    def get_name(self):
        return self.name
    def get_state(self):
        return self.state
    def set_deadend(self):
        self.deadend = True
        self.edges = set()
    def is_deadend(self):
        return self.deadend

class graph:
    def __init__(self, vertices, tableau=None):
        self.vertices = vertices
        if tableau == None:
            self.tableau = basic_tableau()
    def get_edge(self, src, dest):
        assert self.vertices.has_key(src)
        assert self.vertices.has_key(dest)
        edge_list = list(self.vertices[src].get_edges())
        for e in edge_list:
            if e.dest() == dest:
                return e
        return None
    def add_edge(self, src, dest, symbol=None):
        assert self.vertices.has_key(src)
        assert self.vertices.has_key(dest)
        assert self.get_edge(src, dest) == None
        self.vertices[src].add_edge(edge(self.vertices[src],
                                         self.vertices[dest], symbol))
    def add_vertex(self, v):
        assert isinstance(v, vertex)
        self.vertices[v.get_name()] = v
    def get_vertex(self, name):
        assert self.vertices.has_key(name)
        return self.vertices[name]
    def get_vertices(self):
        return self.vertices
    def construct_tableau(self):
        return self.tableau.construct_tableau(self.vertices)
    def display_tableau(self):
        self.tableau.display_tableau(self.vertices)
    
class basic_tableau:
    def construct_tableau(self, vertice_map):
        tableau = {}
        vertices = vertice_map.values()
        for v in vertices:
            src_name = v.get_name()
            edges = v.get_edges()
            tableau[src_name] = {}
            for e in edges:
                dest_name = e.dest().get_name()
                symbol = e.edge_symbol()
                try:
                    tableau[src_name][symbol] += (dest_name,)
                except KeyError:
                    tableau[src_name][symbol] = ()
                    tableau[src_name][symbol] += (dest_name,)
        return tableau
    def display_tableau(self, vertice_map):
        t = self.construct_tableau(vertice_map)
        vertices = vertice_map.values()
        for v in vertices:
            for e in v.get_edges():
                src_name = v.get_name()
                symbol = e.edge_symbol()    
                print 'delta(',src_name,',', symbol,')=',t[src_name][symbol]
