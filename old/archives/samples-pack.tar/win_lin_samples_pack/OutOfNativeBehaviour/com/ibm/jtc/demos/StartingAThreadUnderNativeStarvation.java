/*
 * DeveloperWorks Native Memory Article Sample Code
 * (C) Copyright IBM Corp. 2008. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp.
 */
package com.ibm.jtc.demos;

/**
 * Testcase that attempts to start a thread when the native address
 * space is exhausted.
 *
 * @author <a href="mailto:andhall@uk.ibm.com">Andrew Hall</a>
 */
public class StartingAThreadUnderNativeStarvation
{

    public static void main(String[] args)
    {
        NativeMemoryGlutton.gobbleMemory();
        
        Thread t = new Thread(new Runnable(){

            public void run()
            {
                System.err.println("If you see this message, the thread "
                        + "has started and this demo has not worked as "
                              + "expected");
            }});
        
        t.start();
    }

    final String copyright = "(C) Copyright IBM Corp. 2008. All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";

}
